'use client'

import { useState } from 'react'
import { Globe, Menu, Sparkles, X } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { COUNTRIES } from '@/lib/kojaf-data'
import { useI18n, type DictKey, type Lang } from './i18n'

const LINKS: { href: string; key: DictKey }[] = [
  { href: '#heatmap', key: 'nav.heatmap' },
  { href: '#campaign', key: 'nav.campaign' },
  { href: '#culture', key: 'nav.culture' },
  { href: '#translate', key: 'nav.translate' },
  { href: '#stamp', key: 'nav.stamp' },
  { href: '#funnel', key: 'nav.funnel' },
  { href: '#simulator', key: 'nav.simulator' },
  { href: '#insights', key: 'nav.insights' },
]

const LANGS: { value: Lang; label: string }[] = [
  { value: 'ko', label: '한국어' },
  { value: 'en', label: 'EN' },
]

export function Navbar() {
  const { t, lang, setLang } = useI18n()
  const [open, setOpen] = useState(false)

  const changeLang = (value: Lang) => {
    setLang(value)
    toast.success(value === 'ko' ? '언어가 한국어로 변경되었습니다' : 'Language switched to English')
  }

  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/70 backdrop-blur-xl">
      <nav aria-label="Main" className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 md:px-6">
        <a href="#top" className="flex items-center gap-2.5" aria-label="KOJAF AI home">
          <span className="flex size-8 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-[oklch(0.6_0.2_265)] shadow-[0_0_24px_-4px] shadow-primary/70">
            <Sparkles className="size-4 text-primary-foreground" aria-hidden="true" />
          </span>
          <span className="text-base font-semibold tracking-tight">
            KOJAF <span className="text-gradient">AI</span>
          </span>
        </a>

        <ul className="hidden items-center gap-0.5 xl:flex">
          {LINKS.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className="rounded-md px-2.5 py-2 text-sm text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
              >
                {t(link.key)}
              </a>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-2">
          <div className="hidden items-center gap-0.5 rounded-full border border-border px-2 py-1 2xl:flex" aria-label="Target markets">
            {COUNTRIES.map((c) => (
              <span key={c.code} title={lang === 'ko' ? c.ko : c.en} className="text-sm leading-none">
                <span aria-hidden="true">{c.flag}</span>
                <span className="sr-only">{lang === 'ko' ? c.ko : c.en}</span>
              </span>
            ))}
          </div>

          <div role="radiogroup" aria-label={t('nav.language')} className="flex items-center rounded-full border border-border bg-secondary/50 p-0.5">
            <Globe className="mx-1.5 size-3.5 text-muted-foreground" aria-hidden="true" />
            {LANGS.map((l) => (
              <button
                key={l.value}
                type="button"
                role="radio"
                aria-checked={lang === l.value}
                onClick={() => changeLang(l.value)}
                className={cn(
                  'rounded-full px-2.5 py-1 text-xs font-medium transition-all',
                  lang === l.value ? 'bg-primary text-primary-foreground shadow-[0_0_16px_-4px] shadow-primary' : 'text-muted-foreground hover:text-foreground',
                )}
              >
                {l.label}
              </button>
            ))}
          </div>

          <Button
            className="hidden sm:inline-flex"
            onClick={() => toast.success(lang === 'ko' ? '14일 무료 체험이 시작되었습니다!' : 'Your 14-day free trial has started!')}
          >
            {t('nav.cta')}
          </Button>

          <Button
            variant="ghost"
            size="icon"
            className="xl:hidden"
            aria-label="Toggle menu"
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </Button>
        </div>
      </nav>

      {open ? (
        <ul className="flex flex-col gap-1 border-t border-border/60 px-4 py-3 xl:hidden">
          {LINKS.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                onClick={() => setOpen(false)}
                className="block rounded-md px-3 py-2 text-sm text-muted-foreground hover:bg-accent hover:text-foreground"
              >
                {t(link.key)}
              </a>
            </li>
          ))}
        </ul>
      ) : null}
    </header>
  )
}
