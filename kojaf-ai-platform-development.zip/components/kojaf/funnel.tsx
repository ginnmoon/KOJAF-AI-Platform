'use client'

import { useState } from 'react'
import { ChevronDown, Eye, Languages, MessageCircle, Navigation, Store } from 'lucide-react'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { cn } from '@/lib/utils'
import { COUNTRIES, COUNTRY_FUNNEL_SHARE, FUNNEL, type CountryCode } from '@/lib/kojaf-data'
import { SectionHeader } from './section-header'
import { useI18n, type DictKey } from './i18n'

type Period = keyof typeof FUNNEL

const STAGES: { key: DictKey; icon: typeof Eye }[] = [
  { key: 'funnel.impressions', icon: Eye },
  { key: 'funnel.translation', icon: Languages },
  { key: 'funnel.inquiries', icon: MessageCircle },
  { key: 'funnel.routes', icon: Navigation },
  { key: 'funnel.visits', icon: Store },
]

const COUNTRY_BIAS: Record<CountryCode, number[]> = {
  uz: [1, 1.05, 1.12, 1.08, 1.1],
  kz: [1, 0.98, 1.04, 1.02, 1.0],
  vn: [1, 1.02, 0.96, 1.04, 1.06],
  in: [1, 1.1, 1.0, 0.94, 0.98],
  pa: [1, 0.9, 1.2, 1.1, 1.15],
  ph: [1, 0.96, 1.05, 1.0, 1.03],
}

export function Funnel() {
  const { t, lang } = useI18n()
  const [period, setPeriod] = useState<Period>('7d')
  const [country, setCountry] = useState<CountryCode | 'all'>('all')

  const base = FUNNEL[period]
  const values = base.map((v, i) =>
    country === 'all' ? v : Math.round(v * COUNTRY_FUNNEL_SHARE[country] * COUNTRY_BIAS[country][i]),
  )
  const overall = ((values[4] / values[0]) * 100).toFixed(2)

  return (
    <section id="funnel" aria-labelledby="funnel-title" className="flex scroll-mt-24 flex-col gap-6">
      <SectionHeader
        id="funnel-title"
        eyebrow={t('funnel.eyebrow')}
        title={t('funnel.title')}
        description={t('funnel.desc')}
        action={
          <Tabs value={period} onValueChange={(v) => setPeriod(v as Period)}>
            <TabsList>
              {(['7d', '30d', '90d'] as const).map((p) => (
                <TabsTrigger key={p} value={p} className="px-3 font-mono">
                  {p}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
        }
      />

      <div className="glass flex flex-col gap-6 rounded-2xl p-5 md:p-6">
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setCountry('all')}
            aria-pressed={country === 'all'}
            className={cn(
              'rounded-full border px-3 py-1.5 text-xs transition-all',
              country === 'all' ? 'border-primary bg-primary/20' : 'border-border text-muted-foreground hover:text-foreground',
            )}
          >
            {t('funnel.all')}
          </button>
          {COUNTRIES.map((c) => (
            <button
              key={c.code}
              type="button"
              onClick={() => setCountry(c.code)}
              aria-pressed={country === c.code}
              className={cn(
                'flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs transition-all',
                country === c.code ? 'border-primary bg-primary/20' : 'border-border text-muted-foreground hover:text-foreground',
              )}
            >
              <span aria-hidden="true">{c.flag}</span>
              {lang === 'ko' ? c.ko : c.en}
            </button>
          ))}
          <div className="ml-auto flex items-baseline gap-2">
            <span className="text-xs text-muted-foreground">{t('funnel.overall')}</span>
            <span className="font-mono text-xl font-semibold text-emerald-accent">{overall}%</span>
          </div>
        </div>

        <ol className="mx-auto flex w-full max-w-4xl flex-col gap-1">
          {STAGES.map(({ key, icon: Icon }, i) => {
            const width = 40 + Math.pow(values[i] / values[0], 0.4) * 60
            const rate = i > 0 ? ((values[i] / values[i - 1]) * 100).toFixed(1) : null
            const isLast = i === STAGES.length - 1
            return (
              <li key={key} className="flex flex-col items-center gap-1">
                {rate ? (
                  <span className="flex items-center gap-1 py-0.5 font-mono text-[11px] text-muted-foreground">
                    <ChevronDown className="size-3" aria-hidden="true" />
                    {t('funnel.conversion')} {rate}%
                  </span>
                ) : null}
                <div
                  className={cn(
                    'relative flex h-14 items-center justify-between gap-3 overflow-hidden rounded-xl border px-4 transition-all duration-700',
                    isLast ? 'border-emerald-accent/50 shadow-[0_0_40px_-12px] shadow-emerald-accent' : 'border-primary/30',
                  )}
                  style={{
                    width: `${width}%`,
                    background: isLast
                      ? 'linear-gradient(90deg, oklch(0.78 0.17 162 / 0.35), oklch(0.78 0.17 162 / 0.12))'
                      : `linear-gradient(90deg, oklch(0.64 0.22 ${285 - i * 8} / ${0.42 - i * 0.05}), oklch(0.6 0.2 265 / 0.1))`,
                  }}
                >
                  <span className="flex min-w-0 items-center gap-2.5">
                    <span
                      className={cn(
                        'flex size-8 shrink-0 items-center justify-center rounded-lg',
                        isLast ? 'bg-emerald-accent/20 text-emerald-accent' : 'bg-background/40 text-primary-foreground',
                      )}
                    >
                      <Icon className="size-4" aria-hidden="true" />
                    </span>
                    <span className="truncate text-sm font-medium">{t(key)}</span>
                  </span>
                  <span className="font-mono text-base font-semibold tabular-nums">{values[i].toLocaleString()}</span>
                </div>
              </li>
            )
          })}
        </ol>
      </div>
    </section>
  )
}
