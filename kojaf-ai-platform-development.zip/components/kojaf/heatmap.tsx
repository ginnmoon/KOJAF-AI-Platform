'use client'

import { useEffect, useState } from 'react'
import { Clock, MapPin, TrendingUp } from 'lucide-react'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { cn } from '@/lib/utils'
import { COUNTRIES, DISTRICTS, type CountryCode } from '@/lib/kojaf-data'
import { SectionHeader } from './section-header'
import { useI18n } from './i18n'

type Scope = 'daegu' | 'korea'

const KOREA_REGIONS = [
  { ko: '서울', en: 'Seoul' },
  { ko: '부산', en: 'Busan' },
  { ko: '대구', en: 'Daegu' },
  { ko: '제주', en: 'Jeju' },
  { ko: '인천', en: 'Incheon' },
  { ko: '경주', en: 'Gyeongju' },
] as const

const KOREA_SHIFT = [3, 5, 1, 4, 0, 2]

function heatColor(value: number) {
  const hue = 285 - (value / 100) * 123
  const alpha = 0.18 + (value / 100) * 0.72
  return `oklch(0.7 0.19 ${hue} / ${alpha})`
}

export function Heatmap() {
  const { t, lang } = useI18n()
  const [scope, setScope] = useState<Scope>('daegu')
  const [selected, setSelected] = useState<CountryCode>('vn')
  const [jitter, setJitter] = useState<Record<CountryCode, number>>({ uz: 0, kz: 0, vn: 0, in: 0, pa: 0, ph: 0 })

  useEffect(() => {
    const id = setInterval(() => {
      setJitter((prev) => {
        const next = { ...prev }
        for (const c of COUNTRIES) next[c.code] = Math.round((Math.random() - 0.4) * (c.daegu * 0.03))
        return next
      })
    }, 2500)
    return () => clearInterval(id)
  }, [])

  const regions = scope === 'daegu' ? DISTRICTS : KOREA_REGIONS
  const valuesFor = (districts: number[]) =>
    scope === 'daegu' ? districts : districts.map((_, i) => districts[(i + KOREA_SHIFT[i]) % districts.length])

  const max = Math.max(...COUNTRIES.map((c) => (scope === 'daegu' ? c.daegu : c.korea)))
  const active = COUNTRIES.find((c) => c.code === selected)!

  return (
    <section id="heatmap" aria-labelledby="heatmap-title" className="flex scroll-mt-24 flex-col gap-6">
      <SectionHeader
        id="heatmap-title"
        eyebrow={t('heatmap.eyebrow')}
        title={t('heatmap.title')}
        description={t('heatmap.desc')}
        action={
          <Tabs value={scope} onValueChange={(v) => setScope(v as Scope)}>
            <TabsList>
              <TabsTrigger value="daegu" className="px-3">
                {t('heatmap.daegu')}
              </TabsTrigger>
              <TabsTrigger value="korea" className="px-3">
                {t('heatmap.korea')}
              </TabsTrigger>
            </TabsList>
          </Tabs>
        }
      />

      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
        {COUNTRIES.map((c) => {
          const base = scope === 'daegu' ? c.daegu : c.korea
          const live = base + (scope === 'daegu' ? jitter[c.code] : jitter[c.code] * 12)
          const pct = Math.round((base / max) * 100)
          const isActive = selected === c.code
          return (
            <button
              key={c.code}
              type="button"
              onClick={() => setSelected(c.code)}
              aria-pressed={isActive}
              className={cn(
                'glass group relative flex flex-col gap-3 overflow-hidden rounded-2xl p-4 text-left transition-all hover:-translate-y-0.5',
                isActive && 'ring-2 ring-primary shadow-[0_0_40px_-10px] shadow-primary',
              )}
            >
              <span
                aria-hidden="true"
                className="pointer-events-none absolute -right-8 -top-8 size-24 rounded-full blur-2xl transition-opacity"
                style={{ background: heatColor(pct), opacity: isActive ? 0.9 : 0.5 }}
              />
              <div className="relative flex items-center justify-between">
                <span className="text-2xl leading-none" aria-hidden="true">
                  {c.flag}
                </span>
                <span className="flex items-center gap-1 font-mono text-[10px] uppercase tracking-wider text-emerald-accent">
                  <span className="size-1.5 animate-pulse rounded-full bg-emerald-accent" />
                  {t('heatmap.live')}
                </span>
              </div>
              <div className="relative flex flex-col">
                <span className="text-sm font-medium">{lang === 'ko' ? c.ko : c.en}</span>
                <span className="font-mono text-xl font-semibold tabular-nums tracking-tight">{live.toLocaleString()}</span>
                <span className="text-[11px] text-muted-foreground">{t('heatmap.nowIn')}</span>
              </div>
              <div className="relative h-1.5 w-full overflow-hidden rounded-full bg-secondary">
                <div
                  className="h-full rounded-full transition-all duration-700"
                  style={{ width: `${pct}%`, background: `linear-gradient(90deg, var(--primary), ${heatColor(pct)})` }}
                />
              </div>
              <span className="relative flex items-center gap-1 text-xs text-emerald-accent">
                <TrendingUp className="size-3" aria-hidden="true" />+{c.growth}%
              </span>
            </button>
          )
        })}
      </div>

      <div className="glass grid gap-6 rounded-2xl p-5 lg:grid-cols-[1fr_280px]">
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium">{t('heatmap.districts')}</h3>
            <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
              {t('heatmap.low')}
              <span
                aria-hidden="true"
                className="h-1.5 w-20 rounded-full"
                style={{ background: `linear-gradient(90deg, ${heatColor(5)}, ${heatColor(50)}, ${heatColor(100)})` }}
              />
              {t('heatmap.high')}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full min-w-[560px] border-separate border-spacing-1.5 text-xs">
              <thead>
                <tr>
                  <th scope="col" className="w-28 text-left font-normal text-muted-foreground">
                    <span className="sr-only">Country</span>
                  </th>
                  {regions.map((r) => (
                    <th key={r.en} scope="col" className="pb-1 text-center font-normal text-muted-foreground">
                      {lang === 'ko' ? r.ko : r.en}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {COUNTRIES.map((c) => {
                  const values = valuesFor(c.districts)
                  const rowActive = c.code === selected
                  return (
                    <tr key={c.code} className={cn('transition-opacity', !rowActive && 'opacity-55 hover:opacity-90')}>
                      <th scope="row" className="text-left font-normal">
                        <button type="button" onClick={() => setSelected(c.code)} className="flex items-center gap-2">
                          <span aria-hidden="true">{c.flag}</span>
                          <span className={cn(rowActive ? 'text-foreground' : 'text-muted-foreground')}>
                            {lang === 'ko' ? c.ko : c.en}
                          </span>
                        </button>
                      </th>
                      {values.map((v, i) => (
                        <td key={i} className="p-0">
                          <div
                            className="flex h-9 items-center justify-center rounded-md font-mono text-[11px] text-foreground transition-all duration-500"
                            style={{ background: heatColor(v) }}
                            title={`${lang === 'ko' ? c.ko : c.en} · ${lang === 'ko' ? regions[i].ko : regions[i].en}: ${v}`}
                          >
                            {v}
                          </div>
                        </td>
                      ))}
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>

        <aside className="flex flex-col gap-4 rounded-xl border border-border bg-background/40 p-4" aria-live="polite">
          <div className="flex items-center gap-3">
            <span className="text-3xl leading-none" aria-hidden="true">
              {active.flag}
            </span>
            <div>
              <p className="font-medium">{lang === 'ko' ? active.ko : active.en}</p>
              <p className="text-xs text-muted-foreground">{active.language}</p>
            </div>
          </div>
          <dl className="grid gap-3 text-sm">
            <div className="flex items-center justify-between">
              <dt className="flex items-center gap-2 text-muted-foreground">
                <MapPin className="size-3.5" aria-hidden="true" />
                {t('heatmap.topSpot')}
              </dt>
              <dd className="font-medium">{lang === 'ko' ? active.topSpot.ko : active.topSpot.en}</dd>
            </div>
            <div className="flex items-center justify-between">
              <dt className="flex items-center gap-2 text-muted-foreground">
                <Clock className="size-3.5" aria-hidden="true" />
                {t('heatmap.peak')}
              </dt>
              <dd className="font-mono font-medium">{active.peak}</dd>
            </div>
            <div className="flex items-center justify-between">
              <dt className="flex items-center gap-2 text-muted-foreground">
                <TrendingUp className="size-3.5" aria-hidden="true" />
                WoW
              </dt>
              <dd className="font-mono font-medium text-emerald-accent">+{active.growth}%</dd>
            </div>
          </dl>
          <div className="flex flex-wrap gap-1.5">
            {active.hashtags.slice(0, 4).map((h) => (
              <span key={h} className="rounded-full bg-primary/15 px-2 py-0.5 text-[11px] text-primary-foreground/80">
                {h}
              </span>
            ))}
          </div>
        </aside>
      </div>
    </section>
  )
}
