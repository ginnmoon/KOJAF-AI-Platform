'use client'

import { ArrowRight, Footprints, Megaphone, TrendingUp, Users, Wand2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { COUNTRIES } from '@/lib/kojaf-data'
import { useI18n, type DictKey } from './i18n'

const KPIS: { key: DictKey; value: string; delta: string; icon: typeof Users }[] = [
  { key: 'kpi.visitors', value: '7,500', delta: '+22.4%', icon: Users },
  { key: 'kpi.campaigns', value: '12', delta: '+3', icon: Megaphone },
  { key: 'kpi.roas', value: '6.8x', delta: '+1.2x', icon: TrendingUp },
  { key: 'kpi.visits', value: '1,146', delta: '+18.9%', icon: Footprints },
]

export function Hero() {
  const { t, lang } = useI18n()

  return (
    <section id="top" aria-labelledby="hero-title" className="flex flex-col gap-10 pt-10 md:pt-16">
      <div className="flex flex-col items-start gap-6">
        <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs font-medium text-primary-foreground/90">
          <span className="relative flex size-2">
            <span className="absolute inline-flex size-full animate-pulse-ring rounded-full bg-emerald-accent" />
            <span className="relative inline-flex size-2 rounded-full bg-emerald-accent" />
          </span>
          {t('hero.badge')}
        </span>

        <h1 id="hero-title" className="text-balance text-4xl font-semibold leading-[1.05] tracking-tight md:text-6xl">
          {t('hero.title1')}
          <br />
          <span className="text-gradient">{t('hero.title2')}</span>
        </h1>

        <p className="max-w-2xl text-pretty leading-relaxed text-muted-foreground md:text-lg">{t('hero.subtitle')}</p>

        <div className="flex flex-wrap items-center gap-3">
          <Button size="lg" render={<a href="#campaign" />} nativeButton={false} className="h-11 gap-2 px-5">
            <Wand2 className="size-4" aria-hidden="true" />
            {t('hero.primary')}
          </Button>
          <Button size="lg" variant="outline" render={<a href="#funnel" />} nativeButton={false} className="h-11 gap-2 px-5">
            {t('hero.secondary')}
            <ArrowRight className="size-4" aria-hidden="true" />
          </Button>
        </div>

        <ul className="flex flex-wrap gap-2" aria-label="Target markets">
          {COUNTRIES.map((c) => (
            <li key={c.code} className="glass flex items-center gap-2 rounded-full px-3 py-1.5 text-xs">
              <span aria-hidden="true" className="text-base leading-none">
                {c.flag}
              </span>
              <span className="text-muted-foreground">{lang === 'ko' ? c.ko : c.en}</span>
            </li>
          ))}
        </ul>
      </div>

      <dl className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {KPIS.map(({ key, value, delta, icon: Icon }) => (
          <div key={key} className="glass flex flex-col gap-3 rounded-2xl p-4 md:p-5">
            <div className="flex items-center justify-between">
              <dt className="text-xs text-muted-foreground">{t(key)}</dt>
              <Icon className="size-4 text-primary" aria-hidden="true" />
            </div>
            <dd className="flex flex-col gap-1">
              <span className="font-mono text-2xl font-semibold tracking-tight md:text-3xl">{value}</span>
              <span className="text-xs text-emerald-accent">
                {delta} <span className="text-muted-foreground">{t('kpi.vsLastWeek')}</span>
              </span>
            </dd>
          </div>
        ))}
      </dl>
    </section>
  )
}
