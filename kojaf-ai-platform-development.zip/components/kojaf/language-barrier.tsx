'use client'

import { useState } from 'react'
import { QRCodeSVG } from 'qrcode.react'
import { Download, Info, Languages, MapPinned, UtensilsCrossed, Wifi } from 'lucide-react'
import { toast } from 'sonner'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { COUNTRIES, type CountryCode } from '@/lib/kojaf-data'
import { SectionHeader } from './section-header'
import { useI18n } from './i18n'

const STORE_NAME = '동성로 할매 납작만두'
const WIFI = { ssid: 'KOJAF_Guest_5G', password: 'daegu2026' }

const MENU_KO = [
  { name: '납작만두', price: 6000 },
  { name: '찜갈비', price: 18000 },
  { name: '따로국밥', price: 10000 },
  { name: '아이스 아메리카노', price: 3500 },
]

const INFO_KO = ['주문과 결제는 카운터에서 해주세요', '물은 셀프서비스입니다', '매운 정도를 조절할 수 있습니다']

type Pack = { menu: string[]; wifi: [string, string]; info: string[] }

const PACKS: Record<CountryCode, Pack> = {
  uz: {
    menu: ['Yassi chuchvara (Napjak-mandu)', "Achchiq dimlangan mol qovurg'asi", "Guruch alohida beriladigan sho'rva", 'Muzli amerikano'],
    wifi: ["Wi-Fi tarmog'i", 'Parol'],
    info: ["Buyurtma va to'lov kassada", "Suv — o'z-o'ziga xizmat", 'Achchiqlik darajasini sozlash mumkin'],
  },
  kz: {
    menu: ['Жалпақ тұшпара (Напчак-манду)', 'Ащы бұқтырылған сиыр қабырғасы', 'Күріші бөлек берілетін сорпа', 'Мұзды американо'],
    wifi: ['Wi-Fi желісі', 'Құпиясөз'],
    info: ['Тапсырыс пен төлем кассада', 'Су — өзіне-өзі қызмет көрсету', 'Ащылық деңгейін реттеуге болады'],
  },
  vn: {
    menu: ['Bánh xếp dẹt (Napjak-mandu)', 'Sườn bò hầm cay', 'Canh với cơm riêng (Ttaro-gukbap)', 'Americano đá'],
    wifi: ['Mạng Wi-Fi', 'Mật khẩu'],
    info: ['Gọi món và thanh toán tại quầy', 'Nước uống tự phục vụ', 'Có thể điều chỉnh độ cay'],
  },
  in: {
    menu: ['चपटे डम्पलिंग (नपजक-मांडू)', 'मसालेदार पकी बीफ़ पसलियाँ', 'अलग चावल के साथ सूप', 'आइस्ड अमेरिकानो'],
    wifi: ['वाई-फ़ाई नेटवर्क', 'पासवर्ड'],
    info: ['काउंटर पर ऑर्डर और भुगतान करें', 'पानी स्वयं-सेवा है', 'तीखापन कम-ज़्यादा किया जा सकता है'],
  },
  pa: {
    menu: ['Empanadillas planas (Napjak-mandu)', 'Costillas de res estofadas picantes', 'Sopa con arroz aparte', 'Americano helado'],
    wifi: ['Red Wi-Fi', 'Contraseña'],
    info: ['Pide y paga en el mostrador', 'El agua es autoservicio', 'Podemos ajustar el nivel de picante'],
  },
  ph: {
    menu: ['Flat dumplings (Napjak-mandu)', 'Maanghang na nilagang tadyang ng baka', 'Sabaw na may hiwalay na kanin', 'Iced Americano'],
    wifi: ['Wi-Fi network', 'Password'],
    info: ['Mag-order at magbayad sa counter', 'Self-service ang tubig', 'Puwedeng i-adjust ang anghang'],
  },
}

type MapProvider = 'naver' | 'google'

function mapUrl(provider: MapProvider, lang: CountryCode) {
  const q = encodeURIComponent(`${STORE_NAME} 대구 동성로`)
  return provider === 'naver'
    ? `https://map.naver.com/p/search/${q}?lang=${lang}`
    : `https://www.google.com/maps/search/?api=1&query=${q}&hl=${lang === 'ph' ? 'fil' : lang === 'pa' ? 'es' : lang === 'in' ? 'hi' : lang}`
}

export function LanguageBarrier() {
  const { t, lang } = useI18n()
  const [enabled, setEnabled] = useState(true)
  const [target, setTarget] = useState<CountryCode>('vn')
  const [provider, setProvider] = useState<MapProvider>('naver')

  const country = COUNTRIES.find((c) => c.code === target) ?? COUNTRIES[0]
  const pack = PACKS[target]
  const url = mapUrl(provider, target)

  const toggle = () => {
    setEnabled((v) => {
      const next = !v
      toast.success(
        next
          ? lang === 'ko'
            ? `${country.language} 즉시 번역 켜짐`
            : `Instant ${country.language} translation on`
          : lang === 'ko'
            ? '원문(한국어) 보기로 전환'
            : 'Showing original Korean',
      )
      return next
    })
  }

  const downloadQr = () => {
    const svg = document.getElementById('kojaf-map-qr')
    if (!svg) return
    const blob = new Blob([new XMLSerializer().serializeToString(svg)], { type: 'image/svg+xml' })
    const href = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = href
    a.download = `kojaf-${provider}-map-${target}.svg`
    a.click()
    URL.revokeObjectURL(href)
    toast.success(lang === 'ko' ? 'QR 코드를 다운로드했습니다' : 'QR code downloaded')
  }

  const label = (ko: string, translated: string) => (enabled ? translated : ko)

  return (
    <section id="translate" aria-labelledby="translate-title" className="flex scroll-mt-24 flex-col gap-6">
      <SectionHeader
        id="translate-title"
        eyebrow={t('lb.eyebrow')}
        title={t('lb.title')}
        description={t('lb.desc')}
        action={
          <button
            type="button"
            role="switch"
            aria-checked={enabled}
            onClick={toggle}
            className={cn(
              'flex items-center gap-3 rounded-full border px-2 py-1.5 pr-4 text-sm font-medium transition-colors',
              enabled ? 'border-emerald-accent/50 bg-emerald-accent/10' : 'border-border bg-card/60',
            )}
          >
            <span
              className={cn(
                'relative h-6 w-11 rounded-full transition-colors duration-300',
                enabled ? 'bg-emerald-accent' : 'bg-secondary',
              )}
            >
              <span
                className={cn(
                  'absolute top-0.5 size-5 rounded-full bg-background shadow transition-transform duration-300',
                  enabled ? 'translate-x-5' : 'translate-x-0.5',
                )}
              />
            </span>
            {t('lb.toggle')}
          </button>
        }
      />

      <div role="radiogroup" aria-label={t('lb.language')} className="flex flex-wrap gap-2">
        {COUNTRIES.map((c) => (
          <button
            key={c.code}
            type="button"
            role="radio"
            aria-checked={c.code === target}
            onClick={() => setTarget(c.code)}
            className={cn(
              'flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-medium transition-all',
              c.code === target
                ? 'border-primary/60 bg-primary/15 text-foreground'
                : 'border-border bg-card/50 text-muted-foreground hover:text-foreground',
            )}
          >
            <span aria-hidden="true">{c.flag}</span>
            {c.language}
          </button>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div
          key={`${target}-${enabled}`}
          className="flex flex-col gap-4 rounded-2xl border border-border bg-card/60 p-5 backdrop-blur-xl animate-in fade-in duration-500 lg:col-span-2"
        >
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <UtensilsCrossed className="size-4 text-primary" aria-hidden="true" />
              <h3 className="text-sm font-medium">{STORE_NAME}</h3>
            </div>
            <Badge variant="outline" className={cn('gap-1', enabled && 'border-emerald-accent/40 text-emerald-accent')}>
              <Languages className="size-3" aria-hidden="true" />
              {enabled ? `${country.flag} ${country.language}` : '🇰🇷 한국어'}
            </Badge>
          </div>

          <ul className="divide-y divide-border/60">
            {MENU_KO.map((item, i) => (
              <li key={item.name} className="flex items-center justify-between gap-4 py-3">
                <div className="flex min-w-0 flex-col">
                  <span className="truncate text-sm font-medium">{label(item.name, pack.menu[i])}</span>
                  {enabled ? <span className="text-xs text-muted-foreground">{item.name}</span> : null}
                </div>
                <span className="shrink-0 font-mono text-sm">₩{item.price.toLocaleString()}</span>
              </li>
            ))}
          </ul>

          <div className="grid gap-3 sm:grid-cols-2">
            <div className="flex flex-col gap-2 rounded-xl border border-border bg-background/50 p-4">
              <span className="flex items-center gap-2 text-xs text-muted-foreground">
                <Wifi className="size-3.5" aria-hidden="true" />
                Wi-Fi
              </span>
              <dl className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1 text-sm">
                <dt className="text-muted-foreground">{label('네트워크', pack.wifi[0])}</dt>
                <dd className="font-mono">{WIFI.ssid}</dd>
                <dt className="text-muted-foreground">{label('비밀번호', pack.wifi[1])}</dt>
                <dd className="font-mono">{WIFI.password}</dd>
              </dl>
            </div>
            <div className="flex flex-col gap-2 rounded-xl border border-border bg-background/50 p-4">
              <span className="flex items-center gap-2 text-xs text-muted-foreground">
                <Info className="size-3.5" aria-hidden="true" />
                {t('lb.instructions')}
              </span>
              <ul className="flex flex-col gap-1 text-sm">
                {INFO_KO.map((line, i) => (
                  <li key={line} className="flex gap-2">
                    <span aria-hidden="true" className="text-emerald-accent">
                      •
                    </span>
                    {label(line, pack.info[i])}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-4 rounded-2xl border border-primary/30 bg-gradient-to-b from-primary/15 to-card/60 p-5 backdrop-blur-xl">
          <div className="flex items-center gap-2">
            <MapPinned className="size-4 text-primary" aria-hidden="true" />
            <h3 className="text-sm font-medium">{t('lb.qr')}</h3>
          </div>

          <div role="radiogroup" aria-label={t('lb.qr')} className="grid grid-cols-2 rounded-lg border border-border bg-background/50 p-1">
            {(['naver', 'google'] as const).map((p) => (
              <button
                key={p}
                type="button"
                role="radio"
                aria-checked={provider === p}
                onClick={() => setProvider(p)}
                className={cn(
                  'rounded-md px-3 py-1.5 text-xs font-medium transition-all',
                  provider === p ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground',
                )}
              >
                {p === 'naver' ? (lang === 'ko' ? '네이버 지도' : 'Naver Map') : 'Google Maps'}
              </button>
            ))}
          </div>

          <div
            key={url}
            className="mx-auto flex flex-col items-center gap-3 rounded-2xl bg-white p-4 shadow-[0_0_40px_-10px] shadow-primary animate-in zoom-in-95 fade-in duration-300"
          >
            <QRCodeSVG
              id="kojaf-map-qr"
              value={url}
              size={168}
              level="M"
              fgColor={provider === 'naver' ? '#03a94d' : '#1a73e8'}
              bgColor="#ffffff"
              title={`${provider} map QR`}
            />
            <span className="text-[11px] font-medium text-neutral-600">
              {country.flag} {country.language} · {provider === 'naver' ? 'NAVER' : 'Google'}
            </span>
          </div>

          <p className="break-all rounded-md bg-background/60 px-2 py-1.5 font-mono text-[10px] text-muted-foreground">{url}</p>

          <Button onClick={downloadQr} className="mt-auto gap-2">
            <Download className="size-4" aria-hidden="true" />
            {t('lb.download')}
          </Button>
        </div>
      </div>
    </section>
  )
}
