'use client'

import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react'

export type Lang = 'ko' | 'en'

const dictionary = {
  'nav.heatmap': { ko: '수요 히트맵', en: 'Heatmap' },
  'nav.campaign': { ko: '캠페인 생성', en: 'Campaigns' },
  'nav.funnel': { ko: '전환 퍼널', en: 'Funnel' },
  'nav.simulator': { ko: '매출 시뮬레이터', en: 'Simulator' },
  'nav.insights': { ko: 'AI 인사이트', en: 'AI Insights' },
  'nav.cta': { ko: '무료로 시작', en: 'Start free' },
  'nav.language': { ko: '언어 선택', en: 'Select language' },

  'hero.badge': { ko: '자율 AI 마케팅 · 대구 로컬 비즈니스', en: 'Autonomous AI Marketing · Daegu Local Business' },
  'hero.title1': { ko: '외국인 관광객을', en: 'Turn foreign tourists' },
  'hero.title2': { ko: '실제 매장 방문으로.', en: 'into real store visits.' },
  'hero.subtitle': {
    ko: 'KOJAF AI가 6개국 관광객 수요를 실시간으로 분석하고, SEO 랜딩페이지와 다국어 SNS 캠페인을 자동 생성해 실제 방문까지 추적합니다.',
    en: 'KOJAF AI reads real-time tourist demand from 6 countries, auto-generates SEO landing pages and multilingual social campaigns, then tracks every step to the actual store visit.',
  },
  'hero.primary': { ko: 'AI 캠페인 생성하기', en: 'Generate AI campaign' },
  'hero.secondary': { ko: '전환 퍼널 보기', en: 'View funnel' },

  'kpi.visitors': { ko: '이번 주 외국인 유동', en: 'Foreign footfall this week' },
  'kpi.campaigns': { ko: '실행 중인 AI 캠페인', en: 'Live AI campaigns' },
  'kpi.roas': { ko: '평균 ROAS', en: 'Average ROAS' },
  'kpi.visits': { ko: '실제 매장 방문', en: 'Verified store visits' },
  'kpi.vsLastWeek': { ko: '지난주 대비', en: 'vs last week' },

  'heatmap.eyebrow': { ko: '실시간 수요', en: 'Live demand' },
  'heatmap.title': { ko: '관광객 수요 히트맵', en: 'Tourist Demand Heatmap' },
  'heatmap.desc': {
    ko: '국가별 관광객 밀집도를 지역 단위로 실시간 확인하세요. 국가 카드를 눌러 상권별 분포를 확인할 수 있습니다.',
    en: 'See tourist concentration by country and district in real time. Select a country to inspect its district distribution.',
  },
  'heatmap.daegu': { ko: '대구', en: 'Daegu' },
  'heatmap.korea': { ko: '전국', en: 'All Korea' },
  'heatmap.live': { ko: '실시간', en: 'Live' },
  'heatmap.nowIn': { ko: '현재 체류', en: 'Now in area' },
  'heatmap.peak': { ko: '피크 시간', en: 'Peak hour' },
  'heatmap.topSpot': { ko: '최다 밀집', en: 'Top hotspot' },
  'heatmap.districts': { ko: '상권별 밀집도', en: 'District concentration' },
  'heatmap.low': { ko: '낮음', en: 'Low' },
  'heatmap.high': { ko: '높음', en: 'High' },

  'gen.eyebrow': { ko: '원클릭 생성', en: 'One-click generation' },
  'gen.title': { ko: 'AI SEO & 멀티채널 캠페인 생성기', en: 'AI SEO & Multi-Channel Campaign Generator' },
  'gen.desc': {
    ko: '프롬프트 한 줄로 구글 비즈니스·네이버 지도 SEO 랜딩페이지와 6개국 맞춤 SNS 콘텐츠를 동시에 생성합니다.',
    en: 'One prompt creates a Google Business & Naver Map SEO landing page plus localized social content for 6 countries.',
  },
  'gen.label': { ko: '캠페인 프롬프트', en: 'Campaign prompt' },
  'gen.button': { ko: '원클릭 생성', en: 'Generate' },
  'gen.generating': { ko: '생성 중…', en: 'Generating…' },
  'gen.step1': { ko: '관광객 수요 분석', en: 'Analyzing tourist demand' },
  'gen.step2': { ko: 'SEO 키워드 추출', en: 'Extracting SEO keywords' },
  'gen.step3': { ko: '6개 언어 현지화', en: 'Localizing into 6 languages' },
  'gen.step4': { ko: '채널별 콘텐츠 작성', en: 'Writing channel content' },
  'gen.empty': { ko: '프롬프트를 입력하고 생성 버튼을 눌러보세요.', en: 'Enter a prompt and press Generate.' },
  'gen.tab.landing': { ko: 'SEO 랜딩페이지', en: 'SEO Landing' },
  'gen.tab.instagram': { ko: '인스타그램', en: 'Instagram' },
  'gen.tab.shorts': { ko: '유튜브 쇼츠', en: 'YouTube Shorts' },
  'gen.tab.blog': { ko: '네이버 블로그', en: 'Naver Blog' },
  'gen.targetCountry': { ko: '타깃 국가', en: 'Target country' },
  'gen.copy': { ko: '복사', en: 'Copy' },
  'gen.publish': { ko: '게시 예약', en: 'Schedule' },
  'gen.call': { ko: '전화하기', en: 'Call' },
  'gen.route': { ko: '길찾기', en: 'Get Route' },
  'gen.seoScore': { ko: 'SEO 점수', en: 'SEO score' },

  'funnel.eyebrow': { ko: '실제 성과', en: 'Real outcomes' },
  'funnel.title': { ko: '실제 전환 퍼널', en: 'Real Conversion Funnel' },
  'funnel.desc': {
    ko: '노출부터 실제 매장 방문까지, 모든 단계를 추적합니다.',
    en: 'From impression to the actual store visit — every step tracked.',
  },
  'funnel.impressions': { ko: '노출', en: 'Impressions' },
  'funnel.translation': { ko: '번역 클릭', en: 'Translation clicks' },
  'funnel.inquiries': { ko: 'WhatsApp/IG 문의', en: 'WhatsApp/IG inquiries' },
  'funnel.routes': { ko: '네이버/구글 길찾기', en: 'Naver/Google routes' },
  'funnel.visits': { ko: '실제 매장 방문', en: 'Actual store visits' },
  'funnel.conversion': { ko: '전환율', en: 'Conversion' },
  'funnel.overall': { ko: '전체 전환율', en: 'Overall conversion' },
  'funnel.all': { ko: '전체', en: 'All' },

  'sim.eyebrow': { ko: '예측', en: 'Forecast' },
  'sim.title': { ko: '매출 시뮬레이터', en: 'Revenue Simulator' },
  'sim.desc': {
    ko: 'AI 캠페인 예산을 조정해 추가 매출과 방문 수를 예측하세요.',
    en: 'Adjust your AI campaign budget to forecast extra revenue and visits.',
  },
  'sim.budget': { ko: '월 AI 캠페인 예산', en: 'Monthly AI campaign budget' },
  'sim.ticket': { ko: '객단가', en: 'Avg. ticket size' },
  'sim.extraVisits': { ko: '추가 방문', en: 'Extra visits' },
  'sim.extraRevenue': { ko: '추가 매출', en: 'Extra revenue' },
  'sim.roi': { ko: '예상 ROI', en: 'Projected ROI' },
  'sim.weekly': { ko: '8주 누적 매출 예측', en: '8-week cumulative revenue forecast' },
  'sim.week': { ko: '주', en: 'W' },
  'sim.cafe': { ko: '카페', en: 'Café' },
  'sim.restaurant': { ko: '식당', en: 'Restaurant' },
  'sim.beauty': { ko: '뷰티', en: 'Beauty' },

  'ai.eyebrow': { ko: '다음 주 전략', en: 'Next-week strategy' },
  'ai.title': { ko: 'AI 다음 주 성장 추천', en: 'AI Next-Week Growth Recommendation' },
  'ai.confidence': { ko: '신뢰도', en: 'Confidence' },
  'ai.expected': { ko: '예상 효과', en: 'Expected lift' },
  'ai.apply': { ko: 'AI 전략 적용', en: 'Apply AI Strategy' },
  'ai.applied': { ko: '전략 적용됨', en: 'Strategy applied' },

  'nav.culture': { ko: '컬처 훅', en: 'Culture Hook' },
  'nav.translate': { ko: '즉시 번역', en: 'Translate' },
  'nav.stamp': { ko: '스탬프 투어', en: 'Stamp Tour' },

  'culture.eyebrow': { ko: 'Cultural Hook AI', en: 'Cultural Hook AI' },
  'culture.title': { ko: '크로스컬처 감정 훅 생성기', en: 'Cross-Cultural Emotion Hook Generator' },
  'culture.desc': {
    ko: '국가별 문화 가치(가족·환대·화려함·친근함)를 분석해 AI가 마케팅 훅의 톤, 비주얼, 채널을 자동으로 바꿉니다.',
    en: 'AI reads each culture’s core values — family, hospitality, vibrancy, friendliness — and adapts the hook’s tone, visuals and channels automatically.',
  },
  'culture.hook': { ko: 'AI 현지화 훅', en: 'AI localized hook' },
  'culture.match': { ko: '감정 적합도', en: 'Emotion fit' },
  'culture.regenerate': { ko: '다른 훅 생성', en: 'Regenerate hook' },
  'culture.emotion': { ko: '감정 트리거 분석', en: 'Emotion trigger analysis' },
  'culture.tone': { ko: '추천 톤', en: 'Recommended tone' },
  'culture.visual': { ko: '비주얼 방향', en: 'Visual direction' },
  'culture.channels': { ko: '최적 채널', en: 'Best channels' },

  'lb.eyebrow': { ko: 'Anti-Language Barrier', en: 'Anti-Language Barrier' },
  'lb.title': { ko: '사장님용 즉시 메뉴 & 지도 번역', en: 'Instant Menu & Map Translation for Owners' },
  'lb.desc': {
    ko: '원탭으로 메뉴, Wi-Fi, 매장 안내를 관광객의 모국어로 번역하고 네이버·구글 지도 QR 코드를 바로 만드세요.',
    en: 'One tap translates your menu, Wi-Fi and store instructions into the tourist’s native language, plus a ready-to-print Naver/Google Maps QR.',
  },
  'lb.toggle': { ko: '즉시 번역', en: 'Instant translate' },
  'lb.language': { ko: '관광객 언어', en: 'Tourist language' },
  'lb.instructions': { ko: '매장 안내', en: 'Store instructions' },
  'lb.qr': { ko: '지도 QR 생성기', en: 'Map QR generator' },
  'lb.download': { ko: 'QR 다운로드', en: 'Download QR' },

  'stamp.eyebrow': { ko: '게이미피케이션', en: 'Gamification' },
  'stamp.title': { ko: '대구 스탬프 투어 & 캐시백', en: 'Daegu Stamp Tour & Cashback' },
  'stamp.desc': {
    ko: '관광객이 매장 QR을 스캔해 Daegu Explorer 스탬프를 모으고, 단계별 네이버페이 캐시백을 받습니다. 매장을 눌러 스캔해보세요.',
    en: 'Tourists scan shop QR codes to collect Daegu Explorer stamps and unlock tiered Naver Pay cashback. Tap a shop to scan.',
  },
  'stamp.reset': { ko: '초기화', en: 'Reset' },
  'stamp.progress': { ko: '스탬프 진행도', en: 'Stamp progress' },
  'stamp.scan': { ko: 'QR 스캔', en: 'Scan QR' },
  'stamp.scanning': { ko: '스캔 중…', en: 'Scanning…' },
  'stamp.earned': { ko: '획득 완료', en: 'Collected' },
  'stamp.balance': { ko: '적립된 캐시백', en: 'Cashback earned' },
  'stamp.claim': { ko: '받기', en: 'Claim' },
  'stamp.claimed': { ko: '적립됨', en: 'Claimed' },

  'footer.rights': { ko: '대구에서 만든 글로벌 로컬 마케팅.', en: 'Global local marketing, built in Daegu.' },
} as const

export type DictKey = keyof typeof dictionary

type I18nContextValue = {
  lang: Lang
  setLang: (lang: Lang) => void
  t: (key: DictKey) => string
}

const I18nContext = createContext<I18nContextValue | null>(null)

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Lang>('ko')
  const t = useCallback((key: DictKey) => dictionary[key][lang], [lang])
  const value = useMemo(() => ({ lang, setLang, t }), [lang, t])
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>
}

export function useI18n() {
  const ctx = useContext(I18nContext)
  if (!ctx) throw new Error('useI18n must be used within I18nProvider')
  return ctx
}
