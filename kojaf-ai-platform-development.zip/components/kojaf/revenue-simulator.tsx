'use client'

import { useState } from 'react'
import { Coffee, Sparkle, UtensilsCrossed } from 'lucide-react'
import { Slider } from '@/components/ui/slider'
import { cn } from '@/lib/utils'
import { SectionHeader } from './section-header'
import { useI18n, type DictKey } from './i18n'

const TICKETS: { key: DictKey; value: number; icon: typeof Coffee }[] = [
  { key: 'sim.cafe', value: 18000, icon: Coffee },
  { key: 'sim.restaurant', value: 42000, icon: UtensilsCrossed },
  { key: 'sim.beauty', value: 95000, icon: Sparkle },
]

const MIN = 100_000
const MAX = 5_000_000

function forecast(budget: number, ticket: number) {
  const visits = Math.round(Math.pow(budget / 1000, 0.82) * 4.1)
  const revenue = visits * ticket
  const roi = ((revenue - budget) / budget) * 100
  return { visits, revenue, roi }
}

function formatKrw(value: number, lang: 'ko' | 'en') {
  if (lang === 'ko') {
    if (value >= 100_000_000) return `₩${(value / 100_000_000).toFixed(2)}억`
    if (value >= 10_000) return `₩${Math.round(value / 10_000).toLocaleString()}만`
    return `₩${value.toLocaleString()}`
  }
  if (value >= 1_000_000) return `₩${(value / 1_000_000).toFixed(1)}M`
  return `₩${Math.round(value / 1000).toLocaleString()}K`
}

export function RevenueSimulator() {
  const { t, lang } = useI18n()
  const [budget, setBudget] = useState(1_200_000)
  const [ticket, setTicket] = useState(TICKETS[1].value)

  const { visits, revenue, roi } = forecast(budget, ticket)
  const ramp = [0.42, 0.58, 0.71, 0.82, 0.9, 0.95, 0.98, 1]
  const weekly = ramp.map((r, i) => (revenue / 4) * r * (i + 1) * 0.55)
  const maxWeekly = weekly[weekly.length - 1]

  return (
    <section id="simulator" aria-labelledby="simulator-title" className="flex scroll-mt-24 flex-col gap-6">
      <SectionHeader id="simulator-title" eyebrow={t('sim.eyebrow')} title={t('sim.title')} description={t('sim.desc')} />

      <div className="glass grid gap-6 rounded-2xl p-5 md:p-6 lg:grid-cols-2">
        <div className="flex flex-col gap-6">
          <div className="flex flex-col gap-4">
            <div className="flex items-end justify-between">
              <label id="budget-label" className="text-sm text-muted-foreground">
                {t('sim.budget')}
              </label>
              <span className="font-mono text-2xl font-semibold tracking-tight">{formatKrw(budget, lang)}</span>
            </div>
            <Slider
              aria-labelledby="budget-label"
              min={MIN}
              max={MAX}
              step={50_000}
              value={[budget]}
              onValueChange={(v) => setBudget(Array.isArray(v) ? v[0] : (v as number))}
            />
            <div className="flex justify-between font-mono text-[11px] text-muted-foreground">
              <span>{formatKrw(MIN, lang)}</span>
              <span>{formatKrw(MAX, lang)}</span>
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <span className="text-sm text-muted-foreground">{t('sim.ticket')}</span>
            <div role="radiogroup" aria-label={t('sim.ticket')} className="grid grid-cols-3 gap-2">
              {TICKETS.map(({ key, value, icon: Icon }) => (
                <button
                  key={key}
                  type="button"
                  role="radio"
                  aria-checked={ticket === value}
                  onClick={() => setTicket(value)}
                  className={cn(
                    'flex flex-col items-start gap-1 rounded-xl border p-3 text-left transition-all',
                    ticket === value ? 'border-primary bg-primary/15 shadow-[0_0_24px_-10px] shadow-primary' : 'border-border hover:border-primary/40',
                  )}
                >
                  <Icon className="size-4 text-primary" aria-hidden="true" />
                  <span className="text-sm font-medium">{t(key)}</span>
                  <span className="font-mono text-[11px] text-muted-foreground">{formatKrw(value, lang)}</span>
                </button>
              ))}
            </div>
          </div>

          <dl className="grid grid-cols-3 gap-2">
            <div className="rounded-xl border border-border bg-background/40 p-3">
              <dt className="text-[11px] text-muted-foreground">{t('sim.extraVisits')}</dt>
              <dd className="font-mono text-lg font-semibold tabular-nums">+{visits.toLocaleString()}</dd>
            </div>
            <div className="rounded-xl border border-emerald-accent/30 bg-emerald-accent/10 p-3">
              <dt className="text-[11px] text-muted-foreground">{t('sim.extraRevenue')}</dt>
              <dd className="font-mono text-lg font-semibold tabular-nums text-emerald-accent">{formatKrw(revenue, lang)}</dd>
            </div>
            <div className="rounded-xl border border-border bg-background/40 p-3">
              <dt className="text-[11px] text-muted-foreground">{t('sim.roi')}</dt>
              <dd className="font-mono text-lg font-semibold tabular-nums">{Math.round(roi).toLocaleString()}%</dd>
            </div>
          </dl>
        </div>

        <figure className="flex flex-col gap-4 rounded-xl border border-border bg-background/40 p-4">
          <figcaption className="text-sm text-muted-foreground">{t('sim.weekly')}</figcaption>
          <div className="flex h-56 items-end gap-2" role="img" aria-label={`${t('sim.weekly')}: ${formatKrw(maxWeekly, lang)}`}>
            {weekly.map((w, i) => (
              <div key={i} className="group flex h-full flex-1 flex-col items-center justify-end gap-1.5">
                <span className="font-mono text-[10px] text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100">
                  {formatKrw(w, lang)}
                </span>
                <div className="flex min-h-0 w-full flex-1 items-end">
                  <div
                    className="w-full rounded-t-md bg-gradient-to-t from-primary/50 to-emerald-accent transition-all duration-500 group-hover:brightness-125"
                    style={{ height: `${(w / maxWeekly) * 100}%` }}
                  />
                </div>
                <span className="font-mono text-[10px] text-muted-foreground">
                  {lang === 'ko' ? `${i + 1}${t('sim.week')}` : `${t('sim.week')}${i + 1}`}
                </span>
              </div>
            ))}
          </div>
        </figure>
      </div>
    </section>
  )
}
