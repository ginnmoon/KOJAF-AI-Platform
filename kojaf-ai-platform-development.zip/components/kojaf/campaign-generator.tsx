'use client'

import { useState, type FormEvent } from 'react'
import {
  Check,
  Copy,
  CalendarClock,
  Camera,
  Loader2,
  Lock,
  MapPin,
  Navigation,
  Phone,
  Sparkles,
  Star,
  Wand2,
  Clapperboard,
  FileText,
  Globe2,
} from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { cn } from '@/lib/utils'
import { COUNTRIES, STORE, type CountryCode } from '@/lib/kojaf-data'
import { SectionHeader } from './section-header'
import { useI18n, type DictKey } from './i18n'

const STEPS: DictKey[] = ['gen.step1', 'gen.step2', 'gen.step3', 'gen.step4']
const DEFAULT_PROMPT = '추석 맞이 외국인 할인 이벤트'

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))

function slugFor(prompt: string) {
  if (prompt.includes('추석') || /chuseok/i.test(prompt)) return 'chuseok'
  if (prompt.includes('설날')) return 'seollal'
  if (prompt.includes('크리스마스')) return 'christmas'
  return 'special-offer'
}

export function CampaignGenerator() {
  const { t, lang } = useI18n()
  const [prompt, setPrompt] = useState(DEFAULT_PROMPT)
  const [status, setStatus] = useState<'idle' | 'loading' | 'done'>('idle')
  const [step, setStep] = useState(0)
  const [generatedPrompt, setGeneratedPrompt] = useState('')
  const [country, setCountry] = useState<CountryCode>('uz')

  const generate = async (e?: FormEvent) => {
    e?.preventDefault()
    const value = prompt.trim()
    if (!value || status === 'loading') return
    setStatus('loading')
    for (let i = 0; i < STEPS.length; i++) {
      setStep(i)
      await sleep(550)
    }
    setGeneratedPrompt(value)
    setStatus('done')
    toast.success(lang === 'ko' ? '캠페인 생성 완료' : 'Campaign generated', {
      description: lang === 'ko' ? '랜딩페이지 1개 · SNS 콘텐츠 18개 · 6개 언어' : '1 landing page · 18 social posts · 6 languages',
    })
  }

  const copy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      toast.success(lang === 'ko' ? '클립보드에 복사되었습니다' : 'Copied to clipboard')
    } catch {
      toast.error(lang === 'ko' ? '복사에 실패했습니다' : 'Copy failed')
    }
  }

  const schedule = (channel: string) => {
    const c = COUNTRIES.find((x) => x.code === country)!
    toast.success(lang === 'ko' ? `${channel} 게시 예약 완료` : `${channel} post scheduled`, {
      description: `${c.flag} ${lang === 'ko' ? c.ko : c.en} · ${c.peak} KST`,
    })
  }

  const slug = slugFor(generatedPrompt)
  const active = COUNTRIES.find((c) => c.code === country)!

  return (
    <section id="campaign" aria-labelledby="campaign-title" className="flex scroll-mt-24 flex-col gap-6">
      <SectionHeader id="campaign-title" eyebrow={t('gen.eyebrow')} title={t('gen.title')} description={t('gen.desc')} />

      <div className="glass relative overflow-hidden rounded-2xl p-5 md:p-6">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -left-20 -top-24 size-72 rounded-full bg-primary/25 blur-3xl"
        />
        <form onSubmit={generate} className="relative flex flex-col gap-3">
          <label htmlFor="campaign-prompt" className="text-xs font-medium text-muted-foreground">
            {t('gen.label')}
          </label>
          <div className="flex flex-col gap-3 sm:flex-row">
            <div className="relative flex-1">
              <Sparkles className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-primary" aria-hidden="true" />
              <Input
                id="campaign-prompt"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && (e.nativeEvent.isComposing || e.keyCode === 229)) e.preventDefault()
                }}
                className="h-12 rounded-xl bg-background/60 pl-10 text-base"
                placeholder={DEFAULT_PROMPT}
              />
            </div>
            <Button
              type="submit"
              disabled={status === 'loading' || !prompt.trim()}
              className="h-12 gap-2 rounded-xl bg-gradient-to-r from-primary to-[oklch(0.6_0.2_265)] px-6 text-base shadow-[0_0_30px_-8px] shadow-primary hover:opacity-90"
            >
              {status === 'loading' ? <Loader2 className="size-4 animate-spin" /> : <Wand2 className="size-4" />}
              {status === 'loading' ? t('gen.generating') : t('gen.button')}
            </Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {['추석 맞이 외국인 할인 이벤트', '할랄 메뉴 출시 기념 이벤트', '동성로 야간 뷰티 투어 패키지'].map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setPrompt(s)}
                className="rounded-full border border-border bg-background/40 px-3 py-1 text-xs text-muted-foreground transition-colors hover:border-primary/50 hover:text-foreground"
              >
                {s}
              </button>
            ))}
          </div>
        </form>

        {status === 'loading' ? (
          <ol className="relative mt-6 grid gap-2 sm:grid-cols-4" aria-live="polite">
            {STEPS.map((key, i) => (
              <li
                key={key}
                className={cn(
                  'flex items-center gap-2 rounded-xl border px-3 py-2.5 text-xs transition-all',
                  i < step && 'border-emerald-accent/40 text-emerald-accent',
                  i === step && 'animate-shimmer border-primary/50 text-foreground',
                  i > step && 'border-border text-muted-foreground',
                )}
              >
                {i < step ? (
                  <Check className="size-3.5" aria-hidden="true" />
                ) : i === step ? (
                  <Loader2 className="size-3.5 animate-spin" aria-hidden="true" />
                ) : (
                  <span className="size-3.5 rounded-full border border-current" aria-hidden="true" />
                )}
                {t(key)}
              </li>
            ))}
          </ol>
        ) : null}

        {status === 'idle' ? (
          <p className="relative mt-6 rounded-xl border border-dashed border-border py-10 text-center text-sm text-muted-foreground">
            {t('gen.empty')}
          </p>
        ) : null}

        {status === 'done' ? (
          <Tabs defaultValue="landing" className="relative mt-6 animate-in fade-in slide-in-from-bottom-2 duration-500">
            <TabsList className="h-auto w-full flex-wrap justify-start gap-1 bg-background/50 p-1 sm:w-fit">
              <TabsTrigger value="landing" className="gap-1.5 px-3 py-1.5">
                <Globe2 className="size-3.5" />
                {t('gen.tab.landing')}
              </TabsTrigger>
              <TabsTrigger value="instagram" className="gap-1.5 px-3 py-1.5">
                <Camera className="size-3.5" />
                {t('gen.tab.instagram')}
              </TabsTrigger>
              <TabsTrigger value="shorts" className="gap-1.5 px-3 py-1.5">
                <Clapperboard className="size-3.5" />
                {t('gen.tab.shorts')}
              </TabsTrigger>
              <TabsTrigger value="blog" className="gap-1.5 px-3 py-1.5">
                <FileText className="size-3.5" />
                {t('gen.tab.blog')}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="landing" className="mt-4">
              <LandingPreview slug={slug} prompt={generatedPrompt} />
            </TabsContent>

            {(['instagram', 'shorts', 'blog'] as const).map((channel) => (
              <TabsContent key={channel} value={channel} className="mt-4 flex flex-col gap-4">
                <div className="flex flex-col gap-2">
                  <span className="text-xs text-muted-foreground">{t('gen.targetCountry')}</span>
                  <div role="radiogroup" aria-label={t('gen.targetCountry')} className="flex flex-wrap gap-2">
                    {COUNTRIES.map((c) => (
                      <button
                        key={c.code}
                        type="button"
                        role="radio"
                        aria-checked={country === c.code}
                        onClick={() => setCountry(c.code)}
                        className={cn(
                          'flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs transition-all',
                          country === c.code
                            ? 'border-primary bg-primary/20 text-foreground shadow-[0_0_20px_-6px] shadow-primary'
                            : 'border-border text-muted-foreground hover:text-foreground',
                        )}
                      >
                        <span aria-hidden="true">{c.flag}</span>
                        {c.language}
                      </button>
                    ))}
                  </div>
                </div>

                {channel === 'instagram' ? (
                  <InstagramPost country={active} onCopy={copy} onSchedule={() => schedule('Instagram')} />
                ) : channel === 'shorts' ? (
                  <ShortsScript country={active} onCopy={copy} onSchedule={() => schedule('YouTube Shorts')} />
                ) : (
                  <BlogPost country={active} prompt={generatedPrompt} slug={slug} onCopy={copy} onSchedule={() => schedule('Naver Blog')} />
                )}
              </TabsContent>
            ))}
          </Tabs>
        ) : null}
      </div>
    </section>
  )
}

function ActionBar({ onCopy, onSchedule }: { onCopy: () => void; onSchedule: () => void }) {
  const { t } = useI18n()
  return (
    <div className="flex gap-2">
      <Button variant="outline" size="sm" onClick={onCopy} className="gap-1.5">
        <Copy className="size-3.5" />
        {t('gen.copy')}
      </Button>
      <Button size="sm" onClick={onSchedule} className="gap-1.5 hover:bg-primary/90">
        <CalendarClock className="size-3.5" />
        {t('gen.publish')}
      </Button>
    </div>
  )
}

function LandingPreview({ slug, prompt }: { slug: string; prompt: string }) {
  const { t, lang } = useI18n()
  const url = `kojaf.com/global/${slug}`

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_260px]">
      <div className="overflow-hidden rounded-xl border border-border bg-background/70">
        <div className="flex items-center gap-2 border-b border-border px-3 py-2">
          <div className="flex gap-1.5" aria-hidden="true">
            <span className="size-2.5 rounded-full bg-destructive/70" />
            <span className="size-2.5 rounded-full bg-[oklch(0.8_0.15_80)]/70" />
            <span className="size-2.5 rounded-full bg-emerald-accent/70" />
          </div>
          <div className="flex flex-1 items-center gap-1.5 rounded-md bg-secondary px-2.5 py-1 font-mono text-[11px] text-muted-foreground">
            <Lock className="size-3 text-emerald-accent" aria-hidden="true" />
            {url}
          </div>
        </div>

        <div className="relative flex flex-col gap-5 p-5 md:p-8">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,oklch(0.64_0.22_285/0.25),transparent_60%)]"
          />
          <div className="relative flex flex-wrap gap-1.5" aria-label="Available languages">
            {COUNTRIES.map((c) => (
              <span key={c.code} className="rounded-full bg-secondary px-2 py-0.5 text-[11px]">
                <span aria-hidden="true">{c.flag}</span> {c.language}
              </span>
            ))}
          </div>
          <div className="relative flex flex-col gap-2">
            <span className="w-fit rounded-md bg-emerald-accent/15 px-2 py-0.5 text-xs font-medium text-emerald-accent">
              Chuseok Special · 20% OFF
            </span>
            <h3 className="text-balance text-2xl font-semibold tracking-tight md:text-3xl">{prompt}</h3>
            <p className="text-sm text-muted-foreground">
              {lang === 'ko' ? STORE.ko : STORE.en} · {lang === 'ko' ? STORE.address.ko : STORE.address.en}
            </p>
            <div className="flex items-center gap-1 text-sm">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className="size-3.5 fill-[oklch(0.8_0.15_80)] text-[oklch(0.8_0.15_80)]" aria-hidden="true" />
              ))}
              <span className="ml-1 text-muted-foreground">4.9 · 1,284 reviews</span>
            </div>
          </div>
          <div className="relative grid gap-3 sm:grid-cols-2">
            <Button
              size="lg"
              className="h-12 gap-2 rounded-xl bg-emerald-accent text-base text-background hover:bg-emerald-accent/90"
              onClick={() => toast.success(lang === 'ko' ? '전화 연결 중…' : 'Calling store…', { description: STORE.phone })}
            >
              <Phone className="size-4" />
              {t('gen.call')}
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="h-12 gap-2 rounded-xl text-base"
              onClick={() =>
                toast.success(lang === 'ko' ? '길찾기를 시작합니다' : 'Opening directions', {
                  description: 'Naver Map · Google Maps',
                })
              }
            >
              <Navigation className="size-4" />
              {t('gen.route')}
            </Button>
          </div>
        </div>
      </div>

      <aside className="flex flex-col gap-3 rounded-xl border border-border bg-background/40 p-4">
        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground">{t('gen.seoScore')}</span>
          <span className="font-mono text-2xl font-semibold text-emerald-accent">96</span>
        </div>
        <div className="h-1.5 overflow-hidden rounded-full bg-secondary">
          <div className="h-full w-[96%] rounded-full bg-gradient-to-r from-primary to-emerald-accent" />
        </div>
        <ul className="flex flex-col gap-2 text-xs">
          {[
            'Google Business Profile sync',
            'Naver Smart Place sync',
            'hreflang × 6 languages',
            'LocalBusiness schema.org',
            'Core Web Vitals: Good',
          ].map((item) => (
            <li key={item} className="flex items-center gap-2 text-muted-foreground">
              <Check className="size-3.5 text-emerald-accent" aria-hidden="true" />
              {item}
            </li>
          ))}
        </ul>
        <div className="mt-auto flex items-start gap-2 rounded-lg bg-secondary/60 p-2.5 text-[11px] text-muted-foreground">
          <MapPin className="mt-0.5 size-3.5 shrink-0 text-primary" aria-hidden="true" />
          <span className="font-mono">{url}</span>
        </div>
      </aside>
    </div>
  )
}

type ChildProps = { country: (typeof COUNTRIES)[number]; onCopy: (text: string) => void; onSchedule: () => void }

function InstagramPost({ country, onCopy, onSchedule }: ChildProps) {
  const text = `${country.instagram}\n\n📍 ${STORE.en}\n${country.hashtags.join(' ')}`
  return (
    <div className="grid gap-4 md:grid-cols-[280px_1fr]">
      <div className="relative flex aspect-[4/5] flex-col justify-end overflow-hidden rounded-xl bg-gradient-to-br from-primary via-[oklch(0.5_0.2_265)] to-emerald-accent/80 p-5">
        <div aria-hidden="true" className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,oklch(1_0_0/0.25),transparent_50%)]" />
        <span className="relative text-4xl leading-none" aria-hidden="true">
          {country.flag}
        </span>
        <p className="relative mt-3 text-2xl font-semibold leading-tight text-balance">Chuseok 20% OFF</p>
        <p className="relative text-sm opacity-80">Daegu · {country.language}</p>
      </div>
      <div className="flex flex-col gap-3 rounded-xl border border-border bg-background/50 p-4">
        <p lang={country.code === 'in' ? 'hi' : undefined} className="text-sm leading-relaxed">
          {country.instagram}
        </p>
        <div className="flex flex-wrap gap-1.5">
          {country.hashtags.map((h) => (
            <span key={h} className="text-xs text-primary">
              {h}
            </span>
          ))}
        </div>
        <div className="mt-auto flex items-center justify-between gap-2 pt-2">
          <span className="text-xs text-muted-foreground">Best time · {country.peak} KST</span>
          <ActionBar onCopy={() => onCopy(text)} onSchedule={onSchedule} />
        </div>
      </div>
    </div>
  )
}

function ShortsScript({ country, onCopy, onSchedule }: ChildProps) {
  const scenes = [
    { time: '0–3s', label: 'Hook', line: country.shortsHook },
    { time: '3–8s', label: 'Visual', line: 'Hanok interior pan → steaming songpyeon close-up → 20% OFF sticker' },
    { time: '8–15s', label: 'Value', line: country.instagram.split(/[!.।]/)[0] + '!' },
    { time: '15–20s', label: 'CTA', line: `${country.cta} → kojaf.com/global/chuseok` },
  ]
  const text = scenes.map((s) => `[${s.time}] ${s.label}: ${s.line}`).join('\n')
  return (
    <div className="flex flex-col gap-3 rounded-xl border border-border bg-background/50 p-4">
      <ol className="flex flex-col gap-2">
        {scenes.map((s) => (
          <li key={s.time} className="grid grid-cols-[64px_1fr] gap-3 rounded-lg bg-secondary/50 p-3 text-sm">
            <div className="flex flex-col">
              <span className="font-mono text-xs text-primary">{s.time}</span>
              <span className="text-[11px] uppercase tracking-wider text-muted-foreground">{s.label}</span>
            </div>
            <p className="leading-relaxed">{s.line}</p>
          </li>
        ))}
      </ol>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="text-xs text-muted-foreground">{country.hashtags.slice(0, 3).join(' ')} #Shorts</span>
        <ActionBar onCopy={() => onCopy(text)} onSchedule={onSchedule} />
      </div>
    </div>
  )
}

function BlogPost({ country, prompt, slug, onCopy, onSchedule }: ChildProps & { prompt: string; slug: string }) {
  const title = `[대구 맛집] ${country.ko} 관광객 필수 코스! ${prompt} 총정리`
  const body = `대구 동성로에 위치한 ${STORE.ko}에서 ${prompt}을(를) 진행합니다. 최근 ${country.ko} 관광객 방문이 지난주 대비 ${country.growth}% 증가하며, ${country.topSpot.ko} 인근에서 가장 많이 검색되고 있어요. 여권만 보여주시면 20% 할인과 함께 ${country.language} 메뉴판을 제공해 드립니다.`
  const text = `${title}\n\n${body}\n\nhttps://kojaf.com/global/${slug}\n${country.hashtags.join(' ')}`
  return (
    <article className="flex flex-col gap-3 rounded-xl border border-border bg-background/50 p-4">
      <span className="w-fit rounded bg-emerald-accent/15 px-2 py-0.5 text-[11px] font-medium text-emerald-accent">NAVER BLOG</span>
      <h4 className="text-pretty text-base font-semibold">{title}</h4>
      <p className="text-sm leading-relaxed text-muted-foreground">{body}</p>
      <div className="flex flex-wrap gap-1.5">
        {['대구맛집', '동성로카페', '외국인할인', `${country.ko}관광객`, '추석이벤트'].map((k) => (
          <span key={k} className="rounded-full bg-secondary px-2 py-0.5 text-xs">
            #{k}
          </span>
        ))}
      </div>
      <div className="flex justify-end">
        <ActionBar onCopy={() => onCopy(text)} onSchedule={onSchedule} />
      </div>
    </article>
  )
}
