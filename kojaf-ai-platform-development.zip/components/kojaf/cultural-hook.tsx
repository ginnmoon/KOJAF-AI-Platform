'use client'

import { useState } from 'react'
import { Copy, HeartHandshake, Megaphone, RefreshCw, Sparkles, Wand2 } from 'lucide-react'
import { toast } from 'sonner'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { COUNTRIES, type CountryCode } from '@/lib/kojaf-data'
import { SectionHeader } from './section-header'
import { useI18n } from './i18n'

type Bi = { ko: string; en: string }

type CultureProfile = {
  values: Bi[]
  tone: Bi
  visual: Bi
  palette: string[]
  channels: string[]
  emotions: { label: Bi; value: number }[]
  hooks: { native: string; ko: string; en: string }[]
}

const PROFILES: Record<CountryCode, CultureProfile> = {
  uz: {
    values: [
      { ko: '가족 중심', en: 'Family first' },
      { ko: '손님 환대', en: 'Hospitality' },
      { ko: '할랄 신뢰', en: 'Halal trust' },
    ],
    tone: { ko: '따뜻하고 예의 바른 존댓말', en: 'Warm, respectful and formal' },
    visual: { ko: '가족 식탁 · 따뜻한 골드 톤', en: 'Family table · warm gold tones' },
    palette: ['#d4a24c', '#1f6f5c', '#f3e6cf'],
    channels: ['Telegram', 'Instagram'],
    emotions: [
      { label: { ko: '가족애', en: 'Family' }, value: 96 },
      { label: { ko: '환대', en: 'Hospitality' }, value: 92 },
      { label: { ko: '신뢰', en: 'Trust' }, value: 88 },
      { label: { ko: '활기', en: 'Vibrancy' }, value: 54 },
    ],
    hooks: [
      {
        native: "Oilangiz bilan Daeguda — halol taom va samimiy mehmondo'stlik sizni kutmoqda!",
        ko: '가족과 함께 대구에서 — 할랄 음식과 진심 어린 환대가 기다립니다!',
        en: 'With your family in Daegu — halal food and heartfelt hospitality await!',
      },
      {
        native: "Mehmon otangdan ulug' — Daegu sizni aziz mehmon sifatida kutadi!",
        ko: '"손님은 아버지보다 귀하다" — 대구가 귀한 손님을 기다립니다!',
        en: '"A guest is greater than your father" — Daegu awaits its honored guests!',
      },
    ],
  },
  kz: {
    values: [
      { ko: '가족 중심', en: 'Family first' },
      { ko: '손님 환대', en: 'Hospitality' },
      { ko: '어른 공경', en: 'Respect elders' },
    ],
    tone: { ko: '정중하고 다정한 초대', en: 'Polite, affectionate invitation' },
    visual: { ko: '넓은 식탁(다스타르한) · 하늘색', en: 'Abundant dastarkhan · sky blue' },
    palette: ['#00afca', '#fec50c', '#e8f6f9'],
    channels: ['Instagram', 'TikTok'],
    emotions: [
      { label: { ko: '가족애', en: 'Family' }, value: 93 },
      { label: { ko: '환대', en: 'Hospitality' }, value: 95 },
      { label: { ko: '신뢰', en: 'Trust' }, value: 82 },
      { label: { ko: '활기', en: 'Vibrancy' }, value: 61 },
    ],
    hooks: [
      {
        native: 'Бүкіл отбасыңызбен Тэгуге келіңіз — дастарқанымыз әрқашан ашық!',
        ko: '온 가족과 함께 대구로 오세요 — 우리 식탁은 언제나 열려 있습니다!',
        en: 'Bring the whole family to Daegu — our table is always open!',
      },
      {
        native: 'Қонақ — құт! Тэгу сізді жылы шыраймен күтеді.',
        ko: '"손님은 복이다!" — 대구가 따뜻한 미소로 기다립니다.',
        en: '"A guest is a blessing!" — Daegu welcomes you with a warm smile.',
      },
    ],
  },
  vn: {
    values: [
      { ko: '친구와 함께', en: 'Squad trips' },
      { ko: '가성비', en: 'Great value' },
      { ko: '인생샷', en: 'Photo spots' },
    ],
    tone: { ko: '친근하고 트렌디한 반말 느낌', en: 'Casual, trendy and playful' },
    visual: { ko: '네온 야경 · 셀피 프레임', en: 'Neon nightlife · selfie frames' },
    palette: ['#da251d', '#ffcd00', '#2b2b2b'],
    channels: ['Facebook', 'TikTok', 'Zalo'],
    emotions: [
      { label: { ko: '재미', en: 'Fun' }, value: 94 },
      { label: { ko: '가성비', en: 'Value' }, value: 91 },
      { label: { ko: '트렌드', en: 'Trend' }, value: 88 },
      { label: { ko: '가족애', en: 'Family' }, value: 58 },
    ],
    hooks: [
      {
        native: 'Đi Daegu cùng hội bạn thân — check-in cực chất, giá siêu hời!',
        ko: '절친들과 대구로 — 끝내주는 인증샷, 초특가 가격!',
        en: 'Daegu with your besties — epic check-ins, unbeatable prices!',
      },
      {
        native: 'Ăn ngon, chụp đẹp, giá hạt dẻ — Daegu đang chờ bạn!',
        ko: '맛있게 먹고, 예쁘게 찍고, 가격은 착하게 — 대구가 기다려요!',
        en: 'Eat well, snap pretty, pay little — Daegu is waiting!',
      },
    ],
  },
  in: {
    values: [
      { ko: '화려한 비주얼', en: 'Vibrant visuals' },
      { ko: '축제 분위기', en: 'Celebration' },
      { ko: '채식 옵션', en: 'Veg-friendly' },
    ],
    tone: { ko: '에너지 넘치고 축제 같은', en: 'High-energy and festive' },
    visual: { ko: '채도 높은 사프란·마젠타', en: 'Saturated saffron & magenta' },
    palette: ['#ff9933', '#d6246e', '#138808'],
    channels: ['Instagram', 'YouTube', 'WhatsApp'],
    emotions: [
      { label: { ko: '활기', en: 'Vibrancy' }, value: 97 },
      { label: { ko: '축제', en: 'Festivity' }, value: 92 },
      { label: { ko: '가족애', en: 'Family' }, value: 84 },
      { label: { ko: '가성비', en: 'Value' }, value: 76 },
    ],
    hooks: [
      {
        native: 'रंगों से भरा डेगू — दोस्तों और परिवार के साथ जश्न मनाइए!',
        ko: '색으로 가득한 대구 — 친구, 가족과 함께 축제를 즐기세요!',
        en: 'Daegu in full color — celebrate with friends and family!',
      },
      {
        native: 'शाकाहारी विकल्प उपलब्ध — डेगू का स्वाद, आपके अंदाज़ में!',
        ko: '채식 메뉴 준비 완료 — 당신 스타일의 대구 맛!',
        en: 'Vegetarian options ready — the taste of Daegu, your way!',
      },
    ],
  },
  pa: {
    values: [
      { ko: '친근한 분위기', en: 'Friendly vibe' },
      { ko: '가족 나들이', en: 'Family outings' },
      { ko: '로컬 체험', en: 'Local experience' },
    ],
    tone: { ko: '밝고 친근한 스페인어·영어 믹스', en: 'Bright, friendly Spanish–English mix' },
    visual: { ko: '햇살 · 밝은 원색', en: 'Sunlight · bold primaries' },
    palette: ['#005293', '#d21034', '#ffffff'],
    channels: ['WhatsApp', 'Instagram', 'Facebook'],
    emotions: [
      { label: { ko: '친근함', en: 'Warmth' }, value: 95 },
      { label: { ko: '재미', en: 'Fun' }, value: 86 },
      { label: { ko: '가족애', en: 'Family' }, value: 83 },
      { label: { ko: '신뢰', en: 'Trust' }, value: 72 },
    ],
    hooks: [
      {
        native: '¡Daegu te espera con los brazos abiertos! Buena comida, buena vibra.',
        ko: '대구가 두 팔 벌려 기다려요! 맛있는 음식, 좋은 분위기.',
        en: 'Daegu welcomes you with open arms! Good food, good vibes.',
      },
      {
        native: '¡Ven con tu familia y vive Corea como un local, amigo!',
        ko: '가족과 함께 와서 현지인처럼 한국을 즐기세요, 친구!',
        en: 'Come with your family and live Korea like a local, amigo!',
      },
    ],
  },
  ph: {
    values: [
      { ko: '친근한 영어', en: 'Friendly English' },
      { ko: '바카다(친구 그룹)', en: 'Barkada trips' },
      { ko: '가성비', en: 'Sulit value' },
    ],
    tone: { ko: '유쾌한 타글리시(Taglish)', en: 'Cheerful Taglish' },
    visual: { ko: 'K-팝 무드 · 파스텔 네온', en: 'K-pop mood · pastel neon' },
    palette: ['#0038a8', '#ce1126', '#fcd116'],
    channels: ['Facebook', 'TikTok', 'Instagram'],
    emotions: [
      { label: { ko: '친근함', en: 'Warmth' }, value: 96 },
      { label: { ko: '재미', en: 'Fun' }, value: 93 },
      { label: { ko: '가성비', en: 'Value' }, value: 89 },
      { label: { ko: '가족애', en: 'Family' }, value: 81 },
    ],
    hooks: [
      {
        native: 'Tara na sa Daegu! K-food, K-vibes, at super friendly na mga tao — waiting for you!',
        ko: '대구로 가자! K-푸드, K-바이브, 정말 친절한 사람들이 기다려요!',
        en: "Let's go to Daegu! K-food, K-vibes and super friendly people waiting for you!",
      },
      {
        native: 'Sulit na sulit! Your barkada’s next K-adventure starts here in Daegu.',
        ko: '완전 가성비! 친구들과의 다음 K-어드벤처는 대구에서.',
        en: "Totally worth it! Your squad's next K-adventure starts in Daegu.",
      },
    ],
  },
}

export function CulturalHook() {
  const { t, lang } = useI18n()
  const [code, setCode] = useState<CountryCode>('uz')
  const [variant, setVariant] = useState(0)
  const [spinning, setSpinning] = useState(false)

  const country = COUNTRIES.find((c) => c.code === code) ?? COUNTRIES[0]
  const profile = PROFILES[code]
  const hook = profile.hooks[variant % profile.hooks.length]

  const select = (next: CountryCode) => {
    setCode(next)
    setVariant(0)
  }

  const regenerate = () => {
    setSpinning(true)
    setTimeout(() => {
      setVariant((v) => v + 1)
      setSpinning(false)
    }, 650)
  }

  const copy = async () => {
    await navigator.clipboard?.writeText(hook.native).catch(() => {})
    toast.success(lang === 'ko' ? '현지어 훅이 복사되었습니다' : 'Native hook copied')
  }

  return (
    <section id="culture" aria-labelledby="culture-title" className="flex scroll-mt-24 flex-col gap-6">
      <SectionHeader
        id="culture-title"
        eyebrow={t('culture.eyebrow')}
        title={t('culture.title')}
        description={t('culture.desc')}
      />

      <div role="radiogroup" aria-label={t('gen.targetCountry')} className="grid grid-cols-3 gap-2 md:grid-cols-6">
        {COUNTRIES.map((c) => {
          const active = c.code === code
          return (
            <button
              key={c.code}
              type="button"
              role="radio"
              aria-checked={active}
              onClick={() => select(c.code)}
              className={cn(
                'group flex flex-col items-center gap-1.5 rounded-xl border px-3 py-3 transition-all duration-300',
                active
                  ? 'border-primary/60 bg-primary/15 shadow-[0_0_28px_-8px] shadow-primary'
                  : 'border-border bg-card/50 hover:-translate-y-0.5 hover:border-primary/30',
              )}
            >
              <span aria-hidden="true" className={cn('text-2xl transition-transform', active && 'scale-110')}>
                {c.flag}
              </span>
              <span className="text-xs font-medium">{lang === 'ko' ? c.ko : c.en}</span>
            </button>
          )
        })}
      </div>

      <div className="grid gap-4 lg:grid-cols-5">
        <div
          key={`${code}-${variant}`}
          className="relative overflow-hidden rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/20 via-card/70 to-card/40 p-5 backdrop-blur-xl animate-in fade-in slide-in-from-bottom-2 duration-500 lg:col-span-3 md:p-6"
        >
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -right-20 -top-20 size-64 rounded-full blur-3xl opacity-30"
            style={{ background: profile.palette[0] }}
          />
          <div className="relative flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="flex size-9 items-center justify-center rounded-lg bg-primary/25">
                <Wand2 className="size-4" aria-hidden="true" />
              </span>
              <div className="flex flex-col">
                <span className="text-sm font-medium">{t('culture.hook')}</span>
                <span className="text-xs text-muted-foreground">
                  {country.flag} {country.language}
                </span>
              </div>
            </div>
            <Badge variant="outline" className="gap-1 border-emerald-accent/40 text-emerald-accent">
              <Sparkles className="size-3" aria-hidden="true" />
              {t('culture.match')} {Math.max(...profile.emotions.map((e) => e.value))}%
            </Badge>
          </div>

          <blockquote className={cn('relative mt-6 transition-opacity duration-300', spinning && 'opacity-30')}>
            <p className="text-pretty text-xl font-semibold leading-snug md:text-2xl">{hook.native}</p>
            <p className="mt-3 text-pretty text-sm leading-relaxed text-muted-foreground">
              {lang === 'ko' ? hook.ko : hook.en}
            </p>
          </blockquote>

          <div className="relative mt-6 flex flex-wrap gap-2">
            {profile.values.map((v) => (
              <Badge key={v.en} variant="secondary" className="gap-1">
                <HeartHandshake className="size-3" aria-hidden="true" />
                {lang === 'ko' ? v.ko : v.en}
              </Badge>
            ))}
          </div>

          <div className="relative mt-6 flex flex-wrap gap-2">
            <Button onClick={regenerate} disabled={spinning} className="gap-2">
              <RefreshCw className={cn('size-4', spinning && 'animate-spin')} aria-hidden="true" />
              {t('culture.regenerate')}
            </Button>
            <Button variant="outline" onClick={copy} className="gap-2 bg-transparent">
              <Copy className="size-4" aria-hidden="true" />
              {t('gen.copy')}
            </Button>
          </div>
        </div>

        <div className="flex flex-col gap-4 lg:col-span-2">
          <div className="rounded-2xl border border-border bg-card/60 p-5 backdrop-blur-xl">
            <h3 className="text-sm font-medium">{t('culture.emotion')}</h3>
            <ul className="mt-4 flex flex-col gap-3">
              {profile.emotions.map((e) => (
                <li key={e.label.en} className="flex flex-col gap-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">{lang === 'ko' ? e.label.ko : e.label.en}</span>
                    <span className="font-mono">{e.value}</span>
                  </div>
                  <div className="h-1.5 overflow-hidden rounded-full bg-secondary">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-primary to-emerald-accent transition-[width] duration-700 ease-out"
                      style={{ width: `${e.value}%` }}
                    />
                  </div>
                </li>
              ))}
            </ul>
          </div>

          <dl className="grid grid-cols-2 gap-3 rounded-2xl border border-border bg-card/60 p-5 text-sm backdrop-blur-xl">
            <div className="col-span-2 flex flex-col gap-1">
              <dt className="text-xs text-muted-foreground">{t('culture.tone')}</dt>
              <dd className="font-medium">{lang === 'ko' ? profile.tone.ko : profile.tone.en}</dd>
            </div>
            <div className="col-span-2 flex flex-col gap-1">
              <dt className="text-xs text-muted-foreground">{t('culture.visual')}</dt>
              <dd className="flex items-center gap-2 font-medium">
                <span className="flex -space-x-1" aria-hidden="true">
                  {profile.palette.map((color) => (
                    <span key={color} className="size-4 rounded-full ring-2 ring-card" style={{ background: color }} />
                  ))}
                </span>
                {lang === 'ko' ? profile.visual.ko : profile.visual.en}
              </dd>
            </div>
            <div className="col-span-2 flex flex-col gap-1.5">
              <dt className="flex items-center gap-1 text-xs text-muted-foreground">
                <Megaphone className="size-3" aria-hidden="true" />
                {t('culture.channels')}
              </dt>
              <dd className="flex flex-wrap gap-1.5">
                {profile.channels.map((ch) => (
                  <Badge key={ch} variant="outline">
                    {ch}
                  </Badge>
                ))}
              </dd>
            </div>
          </dl>
        </div>
      </div>
    </section>
  )
}
