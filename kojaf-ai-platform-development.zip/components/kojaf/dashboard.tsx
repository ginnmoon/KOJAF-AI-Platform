'use client'

import { Toaster } from '@/components/ui/sonner'
import { CampaignGenerator } from './campaign-generator'
import { CulturalHook } from './cultural-hook'
import { LanguageBarrier } from './language-barrier'
import { StampTour } from './stamp-tour'
import { Funnel } from './funnel'
import { GrowthRecommendation } from './growth-recommendation'
import { Heatmap } from './heatmap'
import { Hero } from './hero'
import { I18nProvider, useI18n } from './i18n'
import { Navbar } from './navbar'
import { RevenueSimulator } from './revenue-simulator'

export function Dashboard() {
  return (
    <I18nProvider>
      <div className="relative min-h-dvh overflow-x-clip">
        <div aria-hidden="true" className="pointer-events-none fixed inset-0 -z-10">
          <div className="absolute -top-40 left-1/2 h-[520px] w-[900px] -translate-x-1/2 rounded-full bg-primary/20 blur-[120px]" />
          <div className="absolute right-[-10%] top-[40%] h-[420px] w-[420px] rounded-full bg-emerald-accent/10 blur-[120px]" />
          <div className="absolute inset-0 bg-[linear-gradient(to_right,oklch(1_0_0/0.03)_1px,transparent_1px),linear-gradient(to_bottom,oklch(1_0_0/0.03)_1px,transparent_1px)] bg-[size:56px_56px] [mask-image:radial-gradient(ellipse_at_top,black_30%,transparent_75%)]" />
        </div>
        <Navbar />
        <main className="mx-auto flex max-w-7xl flex-col gap-20 px-4 pb-32 md:px-6">
          <Hero />
          <Heatmap />
          <CampaignGenerator />
          <CulturalHook />
          <LanguageBarrier />
          <StampTour />
          <Funnel />
          <RevenueSimulator />
          <GrowthRecommendation />
        </main>
        <Footer />
        <Toaster position="top-center" richColors={false} />
      </div>
    </I18nProvider>
  )
}

function Footer() {
  const { t } = useI18n()
  return (
    <footer className="border-t border-border/60 pb-28 pt-8">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-4 text-xs text-muted-foreground md:flex-row md:px-6">
        <span>© 2026 KOJAF AI</span>
        <span>{t('footer.rights')}</span>
      </div>
    </footer>
  )
}
