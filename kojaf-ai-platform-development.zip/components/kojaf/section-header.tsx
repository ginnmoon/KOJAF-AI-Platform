import type { ReactNode } from 'react'

export function SectionHeader({
  eyebrow,
  title,
  description,
  action,
  id,
}: {
  eyebrow: string
  title: string
  description?: string
  action?: ReactNode
  id?: string
}) {
  return (
    <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
      <div className="flex max-w-2xl flex-col gap-2">
        <span className="text-xs font-medium uppercase tracking-wider text-emerald-accent">{eyebrow}</span>
        <h2 id={id} className="text-balance text-2xl font-semibold tracking-tight md:text-3xl">
          {title}
        </h2>
        {description ? <p className="text-pretty text-sm leading-relaxed text-muted-foreground">{description}</p> : null}
      </div>
      {action}
    </div>
  )
}
