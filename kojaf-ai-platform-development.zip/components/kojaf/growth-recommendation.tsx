'use client'

import { useState } from 'react'
import { BrainCircuit, Check, Clock, Loader2, MapPin, Sparkles, Target } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { SectionHeader } from './section-header'
import { useI18n } from './i18n'

const INSIGHTS = [
  {
    icon: Target,
    flag: '🇻🇳',
    ko: { title: '베트남 관광객 18–21시 동성로 집중', body: '인스타그램 릴스 예산을 35% 증액하고 베트남어 야간 할인 쿠폰을 배포하세요.' },
    en: { title: 'Vietnamese tourists peak 18–21h in Dongseong-ro', body: 'Increase Instagram Reels budget by 35% and push a Vietnamese night-time coupon.' },
    lift: '+142',
  },
  {
    icon: MapPin,
    flag: '🇺🇿',
    ko: { title: '우즈베키스탄 · 서문시장 할랄 검색 급증', body: '구글 비즈니스 프로필에 "Halal" 태그와 우즈베크어 메뉴를 추가하세요.' },
    en: { title: 'Uzbek halal searches surging near Seomun Market', body: 'Add a "Halal" tag and Uzbek menu to your Google Business Profile.' },
    lift: '+86',
  },
  {
    icon: Clock,
    flag: '🇵🇦',
    ko: { title: '파나마 유입 +42% · 문의 응답 지연', body: 'WhatsApp 스페인어 자동응답을 활성화해 평균 응답시간을 2분 이내로 줄이세요.' },
    en: { title: 'Panama inflow +42% · slow inquiry replies', body: 'Enable a Spanish WhatsApp auto-reply to cut average response time under 2 minutes.' },
    lift: '+38',
  },
]

export function GrowthRecommendation() {
  const { t, lang } = useI18n()
  const [state, setState] = useState<'idle' | 'applying' | 'applied'>('idle')

  const apply = () => {
    if (state !== 'idle') return
    setState('applying')
    const promise = new Promise<void>((resolve) => setTimeout(resolve, 1800))
    toast.promise(promise, {
      loading: lang === 'ko' ? 'AI 전략을 캠페인에 적용하는 중…' : 'Applying AI strategy to campaigns…',
      success: lang === 'ko' ? '다음 주 전략이 적용되었습니다 · 예상 방문 +266' : 'Next-week strategy applied · +266 projected visits',
      error: 'Error',
    })
    promise.then(() => setState('applied'))
  }

  return (
    <section id="insights" aria-labelledby="insights-title" className="flex scroll-mt-24 flex-col gap-6">
      <SectionHeader id="insights-title" eyebrow={t('ai.eyebrow')} title={t('ai.title')} />

      <div className="relative overflow-hidden rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/20 via-card/60 to-emerald-accent/10 p-5 backdrop-blur-xl md:p-6">
        <div aria-hidden="true" className="pointer-events-none absolute -right-16 -top-16 size-64 rounded-full bg-emerald-accent/20 blur-3xl" />

        <div className="relative flex flex-wrap items-center gap-4">
          <span className="flex size-11 items-center justify-center rounded-xl bg-primary/25 text-primary-foreground animate-float">
            <BrainCircuit className="size-5" aria-hidden="true" />
          </span>
          <div className="flex flex-1 flex-col">
            <span className="text-sm font-medium">KOJAF Autopilot</span>
            <span className="text-xs text-muted-foreground">
              {lang === 'ko' ? '지난 7일 데이터 128,400건 분석' : 'Analyzed 128,400 events from the last 7 days'}
            </span>
          </div>
          <dl className="flex gap-6">
            <div>
              <dt className="text-[11px] text-muted-foreground">{t('ai.confidence')}</dt>
              <dd className="font-mono text-lg font-semibold">94%</dd>
            </div>
            <div>
              <dt className="text-[11px] text-muted-foreground">{t('ai.expected')}</dt>
              <dd className="font-mono text-lg font-semibold text-emerald-accent">+23%</dd>
            </div>
          </dl>
        </div>

        <ul className="relative mt-6 grid gap-3 md:grid-cols-3">
          {INSIGHTS.map((item) => {
            const copy = lang === 'ko' ? item.ko : item.en
            const Icon = item.icon
            return (
              <li
                key={item.lift}
                className={cn(
                  'flex flex-col gap-3 rounded-xl border bg-background/50 p-4 transition-colors',
                  state === 'applied' ? 'border-emerald-accent/40' : 'border-border',
                )}
              >
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Icon className="size-4 text-primary" aria-hidden="true" />
                    <span aria-hidden="true">{item.flag}</span>
                  </span>
                  {state === 'applied' ? (
                    <Check className="size-4 text-emerald-accent" aria-label={t('ai.applied')} />
                  ) : (
                    <span className="font-mono text-xs text-emerald-accent">
                      {item.lift} {lang === 'ko' ? '방문' : 'visits'}
                    </span>
                  )}
                </div>
                <p className="text-pretty text-sm font-medium">{copy.title}</p>
                <p className="text-pretty text-xs leading-relaxed text-muted-foreground">{copy.body}</p>
              </li>
            )
          })}
        </ul>
      </div>

      <div className="pointer-events-none fixed inset-x-0 bottom-5 z-50 flex justify-center px-4 md:justify-end md:px-8">
        <Button
          onClick={apply}
          disabled={state === 'applying'}
          aria-live="polite"
          className={cn(
            'pointer-events-auto h-12 gap-2 rounded-full px-6 text-sm font-semibold shadow-2xl',
            state === 'applied'
              ? 'bg-emerald-accent text-background hover:bg-emerald-accent/90'
              : 'animate-float bg-gradient-to-r from-primary to-emerald-accent/90 text-primary-foreground shadow-primary/40 hover:opacity-90',
          )}
        >
          {state === 'applying' ? (
            <Loader2 className="size-4 animate-spin" />
          ) : state === 'applied' ? (
            <Check className="size-4" />
          ) : (
            <Sparkles className="size-4" />
          )}
          {state === 'applied' ? t('ai.applied') : t('ai.apply')}
        </Button>
      </div>
    </section>
  )
}
