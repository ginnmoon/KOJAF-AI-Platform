'use client'

import { useState } from 'react'
import { Award, Check, Coffee, Gift, Landmark, Loader2, Lock, MapPin, QrCode, RotateCcw, ShoppingBag, Sparkles, Store, Utensils } from 'lucide-react'
import { toast } from 'sonner'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { SectionHeader } from './section-header'
import { useI18n } from './i18n'

const SHOPS = [
  { id: 'mandu', icon: Utensils, ko: '할매 납작만두', en: 'Halmae Napjak-mandu', area: { ko: '동성로', en: 'Dongseong-ro' } },
  { id: 'cafe', icon: Coffee, ko: '김광석길 카페', en: 'Kim Kwang-seok Café', area: { ko: '김광석길', en: 'Kim Kwang-seok St.' } },
  { id: 'market', icon: ShoppingBag, ko: '서문시장 야시장', en: 'Seomun Night Market', area: { ko: '서문시장', en: 'Seomun Market' } },
  { id: 'galbi', icon: Utensils, ko: '동인동 찜갈비', en: 'Dongin Jjimgalbi', area: { ko: '동인동', en: 'Dongin-dong' } },
  { id: 'hanok', icon: Landmark, ko: '근대골목 투어', en: 'Modern Alley Tour', area: { ko: '중구', en: 'Jung-gu' } },
  { id: 'lake', icon: Coffee, ko: '수성못 디저트', en: 'Suseong Lake Dessert', area: { ko: '수성못', en: 'Suseong Lake' } },
  { id: 'beauty', icon: Store, ko: '동성로 K-뷰티', en: 'Dongseong K-Beauty', area: { ko: '동성로', en: 'Dongseong-ro' } },
  { id: 'makchang', icon: Utensils, ko: '안지랑 막창골목', en: 'Anjirang Makchang Alley', area: { ko: '남구', en: 'Nam-gu' } },
] as const

const REWARDS = [
  { at: 3, amount: 3000, ko: '루키 익스플로러', en: 'Rookie Explorer' },
  { at: 5, amount: 7000, ko: '로컬 마스터', en: 'Local Master' },
  { at: 8, amount: 15000, ko: '대구 레전드', en: 'Daegu Legend' },
]

export function StampTour() {
  const { t, lang } = useI18n()
  const [stamps, setStamps] = useState<string[]>(['mandu', 'cafe'])
  const [scanning, setScanning] = useState<string | null>(null)
  const [claimed, setClaimed] = useState<number[]>([])

  const count = stamps.length
  const level = [...REWARDS].reverse().find((r) => count >= r.at)
  const next = REWARDS.find((r) => count < r.at)
  const claimedTotal = REWARDS.filter((r) => claimed.includes(r.at)).reduce((sum, r) => sum + r.amount, 0)

  const scan = (id: string) => {
    if (scanning || stamps.includes(id)) return
    setScanning(id)
    setTimeout(() => {
      setStamps((s) => [...s, id])
      setScanning(null)
      const shop = SHOPS.find((s) => s.id === id)
      const unlocked = REWARDS.find((r) => r.at === count + 1)
      toast.success(
        unlocked
          ? lang === 'ko'
            ? `${unlocked.ko} 달성! ₩${unlocked.amount.toLocaleString()} 캐시백 잠금 해제`
            : `${unlocked.en} unlocked! ₩${unlocked.amount.toLocaleString()} cashback ready`
          : lang === 'ko'
            ? `${shop?.ko} 스탬프 획득!`
            : `Stamp earned at ${shop?.en}!`,
      )
    }, 1100)
  }

  const claim = (at: number, amount: number) => {
    setClaimed((c) => [...c, at])
    toast.success(
      lang === 'ko'
        ? `네이버페이 포인트 ₩${amount.toLocaleString()}이 적립되었습니다`
        : `₩${amount.toLocaleString()} credited to Naver Pay`,
    )
  }

  const reset = () => {
    setStamps([])
    setClaimed([])
  }

  return (
    <section id="stamp" aria-labelledby="stamp-title" className="flex scroll-mt-24 flex-col gap-6">
      <SectionHeader
        id="stamp-title"
        eyebrow={t('stamp.eyebrow')}
        title={t('stamp.title')}
        description={t('stamp.desc')}
        action={
          <Button variant="outline" onClick={reset} className="gap-2 bg-transparent">
            <RotateCcw className="size-4" aria-hidden="true" />
            {t('stamp.reset')}
          </Button>
        }
      />

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="relative overflow-hidden rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/25 via-card/70 to-emerald-accent/10 p-5 backdrop-blur-xl lg:col-span-2 md:p-6">
          <div aria-hidden="true" className="pointer-events-none absolute -left-16 -bottom-20 size-64 rounded-full bg-primary/25 blur-3xl" />

          <div className="relative flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="flex size-11 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-emerald-accent animate-float">
                <Award className="size-5 text-primary-foreground" aria-hidden="true" />
              </span>
              <div className="flex flex-col">
                <span className="text-sm font-semibold">Daegu Explorer Pass</span>
                <span className="text-xs text-muted-foreground">
                  {level ? (lang === 'ko' ? level.ko : level.en) : lang === 'ko' ? '새내기 여행자' : 'New traveler'}
                </span>
              </div>
            </div>
            <div className="flex items-baseline gap-1" aria-live="polite">
              <span className="font-mono text-3xl font-semibold">{count}</span>
              <span className="font-mono text-sm text-muted-foreground">/ {SHOPS.length}</span>
            </div>
          </div>

          <div className="relative mt-5 h-2 overflow-hidden rounded-full bg-secondary" role="progressbar" aria-valuemin={0} aria-valuemax={SHOPS.length} aria-valuenow={count} aria-label={t('stamp.progress')}>
            <div
              className="h-full rounded-full bg-gradient-to-r from-primary to-emerald-accent transition-[width] duration-700 ease-out"
              style={{ width: `${(count / SHOPS.length) * 100}%` }}
            />
          </div>
          <p className="relative mt-2 text-xs text-muted-foreground">
            {next
              ? lang === 'ko'
                ? `${next.at - count}개 더 모으면 ₩${next.amount.toLocaleString()} 캐시백`
                : `${next.at - count} more for ₩${next.amount.toLocaleString()} cashback`
              : lang === 'ko'
                ? '모든 스탬프를 모았습니다!'
                : 'All stamps collected!'}
          </p>

          <ul className="relative mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {SHOPS.map((shop) => {
              const earned = stamps.includes(shop.id)
              const isScanning = scanning === shop.id
              const Icon = shop.icon
              return (
                <li key={shop.id}>
                  <button
                    type="button"
                    onClick={() => scan(shop.id)}
                    disabled={earned || Boolean(scanning)}
                    aria-label={`${lang === 'ko' ? shop.ko : shop.en} — ${earned ? t('stamp.earned') : t('stamp.scan')}`}
                    className={cn(
                      'group relative flex aspect-square w-full flex-col items-center justify-center gap-2 overflow-hidden rounded-xl border p-3 text-center transition-all duration-300',
                      earned
                        ? 'border-emerald-accent/50 bg-emerald-accent/10'
                        : 'border-dashed border-border bg-background/40 hover:-translate-y-0.5 hover:border-primary/50 disabled:hover:translate-y-0',
                    )}
                  >
                    {isScanning ? (
                      <span aria-hidden="true" className="absolute inset-x-2 top-2 h-0.5 animate-[scan_1.1s_ease-in-out] rounded-full bg-emerald-accent shadow-[0_0_12px] shadow-emerald-accent" />
                    ) : null}
                    <span
                      className={cn(
                        'flex size-11 items-center justify-center rounded-full transition-all duration-500',
                        earned
                          ? 'rotate-[-12deg] border-2 border-emerald-accent bg-emerald-accent/20 text-emerald-accent animate-in zoom-in-50'
                          : 'bg-secondary text-muted-foreground group-hover:text-foreground',
                      )}
                    >
                      {isScanning ? (
                        <Loader2 className="size-5 animate-spin" aria-hidden="true" />
                      ) : earned ? (
                        <Check className="size-5" aria-hidden="true" />
                      ) : (
                        <Icon className="size-5" aria-hidden="true" />
                      )}
                    </span>
                    <span className="line-clamp-2 text-xs font-medium leading-tight">{lang === 'ko' ? shop.ko : shop.en}</span>
                    <span className="flex items-center gap-1 text-[10px] text-muted-foreground">
                      {earned ? (
                        t('stamp.earned')
                      ) : (
                        <>
                          <QrCode className="size-3" aria-hidden="true" />
                          {isScanning ? t('stamp.scanning') : t('stamp.scan')}
                        </>
                      )}
                    </span>
                  </button>
                </li>
              )
            })}
          </ul>
        </div>

        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between rounded-2xl border border-[#03c75a]/40 bg-[#03c75a]/10 p-5">
            <div className="flex flex-col gap-1">
              <span className="text-xs text-muted-foreground">{t('stamp.balance')}</span>
              <span className="font-mono text-2xl font-semibold" aria-live="polite">
                ₩{claimedTotal.toLocaleString()}
              </span>
            </div>
            <span className="rounded-md bg-[#03c75a] px-2 py-1 text-xs font-bold text-white">N Pay</span>
          </div>

          <ul className="flex flex-col gap-3">
            {REWARDS.map((r) => {
              const unlocked = count >= r.at
              const isClaimed = claimed.includes(r.at)
              return (
                <li
                  key={r.at}
                  className={cn(
                    'flex items-center gap-3 rounded-xl border p-4 transition-all duration-500',
                    unlocked ? 'border-primary/40 bg-card/80' : 'border-border bg-card/40 opacity-70',
                  )}
                >
                  <span
                    className={cn(
                      'flex size-10 shrink-0 items-center justify-center rounded-lg',
                      unlocked ? 'bg-gradient-to-br from-primary to-emerald-accent text-primary-foreground' : 'bg-secondary text-muted-foreground',
                    )}
                  >
                    {unlocked ? <Gift className="size-4" aria-hidden="true" /> : <Lock className="size-4" aria-hidden="true" />}
                  </span>
                  <div className="flex min-w-0 flex-1 flex-col">
                    <span className="flex items-center gap-2 text-sm font-medium">
                      {lang === 'ko' ? r.ko : r.en}
                      <Badge variant="outline" className="px-1.5 py-0 text-[10px]">
                        <MapPin className="size-2.5" aria-hidden="true" />
                        {r.at}
                      </Badge>
                    </span>
                    <span className="font-mono text-xs text-emerald-accent">₩{r.amount.toLocaleString()} cashback</span>
                  </div>
                  <Button
                    size="sm"
                    disabled={!unlocked || isClaimed}
                    onClick={() => claim(r.at, r.amount)}
                    className={cn(isClaimed && 'bg-emerald-accent text-background')}
                  >
                    {isClaimed ? <Check className="size-3.5" aria-hidden="true" /> : <Sparkles className="size-3.5" aria-hidden="true" />}
                    {isClaimed ? t('stamp.claimed') : t('stamp.claim')}
                  </Button>
                </li>
              )
            })}
          </ul>
        </div>
      </div>
    </section>
  )
}
