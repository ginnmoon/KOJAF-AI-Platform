export type CountryCode = 'uz' | 'kz' | 'vn' | 'in' | 'pa' | 'ph'

export type Country = {
  code: CountryCode
  flag: string
  ko: string
  en: string
  language: string
  daegu: number
  korea: number
  growth: number
  peak: string
  topSpot: { ko: string; en: string }
  districts: number[]
  hashtags: string[]
  instagram: string
  shortsHook: string
  cta: string
}

export const DISTRICTS = [
  { ko: '동성로', en: 'Dongseong-ro' },
  { ko: '서문시장', en: 'Seomun Market' },
  { ko: '수성못', en: 'Suseong Lake' },
  { ko: '김광석길', en: 'Kim Kwang-seok St.' },
  { ko: '동대구역', en: 'Dongdaegu Stn.' },
  { ko: '이월드', en: 'E-World' },
] as const

export const COUNTRIES: Country[] = [
  {
    code: 'uz',
    flag: '🇺🇿',
    ko: '우즈베키스탄',
    en: 'Uzbekistan',
    language: "O'zbekcha",
    daegu: 1284,
    korea: 18420,
    growth: 24.6,
    peak: '19:00',
    topSpot: { ko: '서문시장', en: 'Seomun Market' },
    districts: [62, 94, 38, 41, 70, 33],
    hashtags: ['#Koreyada', '#Daegu', '#ChuseokSale', '#OzbekistonKoreya', '#HalolFood', '#SayohatKoreya'],
    instagram:
      "Chuseok bayrami munosabati bilan barcha xorijlik mehmonlarimizga 20% chegirma! Daegu markazida halol taomlar va iliq mehmondo'stlik sizni kutmoqda. Pasportingizni ko'rsating va sovg'a oling!",
    shortsHook: 'Koreyada eng arzon halol taom qayerda? Daegu!',
    cta: "Hoziroq yo'nalishni oling",
  },
  {
    code: 'kz',
    flag: '🇰🇿',
    ko: '카자흐스탄',
    en: 'Kazakhstan',
    language: 'Қазақша',
    daegu: 962,
    korea: 14105,
    growth: 18.2,
    peak: '20:00',
    topSpot: { ko: '동성로', en: 'Dongseong-ro' },
    districts: [88, 52, 44, 36, 64, 40],
    hashtags: ['#Корея', '#Тэгу', '#Чхусок', '#ҚазақстанКорея', '#KoreaTravel', '#Жеңілдік'],
    instagram:
      'Чхусок мерекесіне орай барлық шетелдік қонақтарға 20% жеңілдік! Тэгу орталығындағы дүкенімізге келіп, корей дәстүрлі тағамдарын татып көріңіз. Паспортыңызды көрсетіп, сыйлық алыңыз!',
    shortsHook: 'Тэгудағы ең дәмді корей тағамы — осында!',
    cta: 'Бағытты қазір алыңыз',
  },
  {
    code: 'vn',
    flag: '🇻🇳',
    ko: '베트남',
    en: 'Vietnam',
    language: 'Tiếng Việt',
    daegu: 2318,
    korea: 41260,
    growth: 31.4,
    peak: '18:00',
    topSpot: { ko: '동성로', en: 'Dongseong-ro' },
    districts: [96, 78, 66, 72, 58, 81],
    hashtags: ['#DuLichHanQuoc', '#Daegu', '#Chuseok', '#NguoiVietTaiHan', '#AnUongHanQuoc', '#GiamGia'],
    instagram:
      'Mừng Tết Trung Thu Hàn Quốc (Chuseok), giảm ngay 20% cho tất cả du khách nước ngoài! Ghé cửa hàng của chúng tôi tại trung tâm Daegu để thưởng thức món ăn truyền thống. Xuất trình hộ chiếu để nhận quà!',
    shortsHook: 'Đến Daegu mùa Chuseok? Đừng bỏ lỡ quán này!',
    cta: 'Chỉ đường ngay',
  },
  {
    code: 'in',
    flag: '🇮🇳',
    ko: '인도',
    en: 'India',
    language: 'हिन्दी',
    daegu: 1046,
    korea: 16880,
    growth: 27.9,
    peak: '13:00',
    topSpot: { ko: '동대구역', en: 'Dongdaegu Stn.' },
    districts: [58, 46, 52, 30, 92, 48],
    hashtags: ['#KoreaTravel', '#Daegu', '#ChuseokOffer', '#IndiansInKorea', '#VegFriendly', '#कोरिया'],
    instagram:
      'चुसोक त्योहार पर सभी विदेशी पर्यटकों के लिए 20% की छूट! डेगू के बीचों-बीच हमारे स्टोर पर आइए — शाकाहारी विकल्प भी उपलब्ध हैं। पासपोर्ट दिखाएँ और उपहार पाएँ!',
    shortsHook: 'कोरिया में शाकाहारी खाना? डेगू में यहाँ मिलेगा!',
    cta: 'अभी रास्ता देखें',
  },
  {
    code: 'pa',
    flag: '🇵🇦',
    ko: '파나마',
    en: 'Panama',
    language: 'Español',
    daegu: 318,
    korea: 4120,
    growth: 42.1,
    peak: '21:00',
    topSpot: { ko: '김광석길', en: 'Kim Kwang-seok St.' },
    districts: [54, 28, 40, 76, 34, 22],
    hashtags: ['#ViajarACorea', '#Daegu', '#Chuseok', '#PanamaEnCorea', '#KFood', '#Descuento'],
    instagram:
      '¡Por Chuseok, 20% de descuento para todos los turistas extranjeros! Visita nuestra tienda en el centro de Daegu y prueba la auténtica comida coreana. ¡Muestra tu pasaporte y recibe un regalo!',
    shortsHook: '¿Vas a Corea en Chuseok? ¡Tienes que venir aquí!',
    cta: 'Obtén la ruta ahora',
  },
  {
    code: 'ph',
    flag: '🇵🇭',
    ko: '필리핀',
    en: 'Philippines',
    language: 'Filipino',
    daegu: 1572,
    korea: 28940,
    growth: 15.3,
    peak: '17:00',
    topSpot: { ko: '이월드', en: 'E-World' },
    districts: [72, 50, 60, 48, 56, 90],
    hashtags: ['#KoreaTrip', '#Daegu', '#ChuseokSale', '#PinoyInKorea', '#KFoodTrip', '#Discount'],
    instagram:
      'Ngayong Chuseok, 20% discount para sa lahat ng foreign tourists! Bisitahin ang aming tindahan sa gitna ng Daegu at tikman ang tunay na Korean food. Ipakita lang ang passport at may libreng regalo!',
    shortsHook: 'Pupunta ka ba sa Daegu ngayong Chuseok? Dito ka kumain!',
    cta: 'Kunin ang direksyon ngayon',
  },
]

export const FUNNEL = {
  '7d': [128400, 31820, 4210, 2380, 1146],
  '30d': [542900, 128300, 17460, 9820, 4718],
  '90d': [1487200, 356100, 48120, 27460, 13390],
} as const

export const COUNTRY_FUNNEL_SHARE: Record<CountryCode, number> = {
  uz: 0.16,
  kz: 0.12,
  vn: 0.29,
  in: 0.14,
  pa: 0.05,
  ph: 0.24,
}

export const STORE = {
  ko: '대구 한옥 카페 & 비스트로',
  en: 'Daegu Hanok Café & Bistro',
  phone: '+82-53-123-4567',
  address: { ko: '대구 중구 동성로 2길 34', en: '34 Dongseong-ro 2-gil, Jung-gu, Daegu' },
}
