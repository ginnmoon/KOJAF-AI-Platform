import { Dashboard } from '@/components/kojaf/dashboard'

export default function Page() {
  return <Dashboard />
}
